"""
SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
SPDX-License-Identifier: MIT

Resource management module for SimaticAI SDK.

This module provides functionality to manage and copy built-in SimaticAI SDK resources
(such as ImageSet utilities) to user component directories. It handles source code copying,
dependency management, and automatic requirements.txt updates.

The module maintains a registry of available resources with their file paths and
dependencies, allowing users to easily integrate common SDK utilities into their
pipeline components.

Key Features:
    - Resource registry management
    - Automatic dependency resolution
    - Resource file copying to target directories
    - Automatic update of requirements.txt file
    - Built-in support for ImageSet resource

Available Resources:
    - ImageSet: Provides image dataset handling utilities with OpenCV dependencies

Example Usage:
    >>> from simaticai.common.resources import copy_resource_to
    >>> copy_resource_to("ImageSet", "my_component_source_dir")
    # This copies imageset.py and updates requirements.txt with necessary dependencies

Functions:
    - get_resource: Retrieves information about a specific SDK resource
    - copy_resource_to: Copies a resource file to a component directory with dependencies

Constants:
    - SIMATICAI_RESOURCE_KEYS: List of available resource names
    - SIMATICAI_RESOURCES: Registry dictionary of all built-in resources
"""
