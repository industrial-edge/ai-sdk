"""
SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
SPDX-License-Identifier: MIT

Common constants used in 'packaging' module.
"""

README_HTML = "README.html"
REQUIREMENTS_TXT = "requirements.txt"
PYTHON_PACKAGES = "PythonPackages"
PYTHON_PACKAGES_ZIP = f"{PYTHON_PACKAGES}.zip"
PIPELINE_CONFIG = "pipeline_config.yml"
DATALINK_METADATA = "datalink_metadata.yml"
RUNTIME_CONFIG = "runtime_config.yml"
TELEMETRY_YAML = "telemetry_data.yml"

MSG_NOT_FOUND = "not found"

PACKAGE_SIZE_LIMIT = int(2.2 * 1000 * 1000 * 1000)
""" Maximum size of zipped pipeline package is limited to 2.2 GB. """

PLATFORMS = [
    "any",
    "manylinux1_x86_64",
    "manylinux2010_x86_64",
    "manylinux2014_x86_64",
    "linux_x86_64"
] + [ f"manylinux_2_{glibc_minor}_x86_64" for glibc_minor in range(5,32) ]
""" List of platform tags supported by AI Inference Server. """
