# SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
# SPDX-License-Identifier: MIT

import re
from enum import Enum

supported_types = [
    "Bool", "BoolArray",
    "UInt8", "UInt8Array",
    "UInt16", "UInt16Array",
    "UInt32", "UInt32Array",
    "UInt64", "UInt64Array",
    "Int8", "Int8Array",
    "Int16", "Int16Array",
    "Int32", "Int32Array",
    "Int64", "Int64Array",
    "Float32", "Float32Array",
    "Float64", "Float64Array",
    "Boolean", "BooleanArray",
    "Integer", "IntegerArray",
    "Double", "DoubleArray",
    "String", "StringArray",
    "Object",
    "Binary",
    "ImageSet"
]
"""
List of input/output data types supported by AI Inference Server.

Custom types can also be provided when specifying pipeline inputs/outputs, but AI SDK will raise a warning message in this case.
"""

class TypeValidationFlags(Enum):
    """
    Enumeration of type validation flags for supported types.
    This enum defines various validation error conditions that can occur when
    validating type definitions of pipeline inputs, outputs, variables and parameters.
    Each flag represents a specific validation issue related to type definitions and array handling.
    Attributes:
        INVALID_TYPE (str): Indicates that the provided type has an invalid syntax.
        UNSUPPORTED_TYPE (str): Indicates that the type is valid in syntax but not among the list of supported types.
        ARRAY_WITH_MISSING_SIZE (str): Indicates that the type is defined as an array, but the size is not specified.
        ARRAY_WITH_INVALID_SIZE (str): Indicates that the type is defined as an array, but the size is invalid.
        ARRAY_WITH_MULTI_DIMENSIONS (str): Indicates that the type is defined as a multi-dimensional array.
        NON_ARRAY_TYPE_WITH_SIZE (str): Indicates that the type is not defined as an array, but a size is specified.
    """

    INVALID_TYPE = "Invalid type"
    UNSUPPORTED_TYPE = "Unsupported type"
    ARRAY_WITH_MISSING_SIZE = "Array with missing size"
    ARRAY_WITH_INVALID_SIZE = "Array with invalid size"
    ARRAY_WITH_MULTI_DIMENSIONS = "Array with multiple dimensions"
    NON_ARRAY_TYPE_WITH_SIZE = "Non-array type with size"

def type_validation_flags(_type: str, _supported_types: list = supported_types) -> set:
    """
    Validate a type string and return a set of validation flags indicating any issues.
    This function parses a type string to extract the base type name and optional array size
    specifiers. It then validates the type against a list of supported types and checks for
    common type specification errors.
    Args:
        _type (str): The type string to validate. Can be a simple type name (e.g., 'Boolean', 'String')
                     or an array type with size specifiers (e.g., 'BooleanArray[10]', 'StringArray[5]').
        _supported_types (list, optional): List of supported type names to validate against.
                                           Defaults to the module-level `supported_types` list.
    Returns:
        set: A set of TypeValidationFlags indicating validation results.
    """

    flags = set()

    type_pattern = re.compile(r"([a-zA-Z0-9]+)((\[[0-9\-]*\])*)")  # a type name, optionally followed by array size specifiers like [123]
    match = type_pattern.fullmatch(_type)

    if not match:
        flags.add(TypeValidationFlags.INVALID_TYPE)
        return flags

    type_base = match.group(1)  # the part before a specified size, e.g., BooleanArray
    type_array_size = match.group(2)  # the part with the specified size, including brackets (e.g., '[123]')

    if type_base not in _supported_types:
        flags.add(TypeValidationFlags.UNSUPPORTED_TYPE)

    if not type_array_size:
        if type_base.endswith("Array"):
            flags.add(TypeValidationFlags.ARRAY_WITH_MISSING_SIZE)
        return flags

    if not type_base.endswith("Array"):
        flags.add(TypeValidationFlags.NON_ARRAY_TYPE_WITH_SIZE)

    if type_array_size.count('[') > 1:
        flags.add(TypeValidationFlags.ARRAY_WITH_MULTI_DIMENSIONS)
        return flags

    size = type_array_size.strip('[]')
    try:
        size = int(size)
        if size <= 0:
            flags.add(TypeValidationFlags.ARRAY_WITH_INVALID_SIZE)
    except ValueError:
        flags.add(TypeValidationFlags.ARRAY_WITH_INVALID_SIZE)

    return flags
