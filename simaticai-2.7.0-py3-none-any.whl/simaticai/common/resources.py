# SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
# SPDX-License-Identifier: MIT

import logging
import os
import sys
import shutil
from pathlib import Path
from importlib import resources as module_resources
from importlib import metadata as importlib_metadata
from simaticai.helpers import pep508

logging.basicConfig()
logging.getLogger().handlers = [logging.StreamHandler(sys.stdout)]
_logger = logging.getLogger(__name__)
_logger.setLevel(logging.INFO)

__all__ = ['SIMATICAI_RESOURCE_KEYS', 'copy_resource_to', 'get_resource']

"""
Registry of built-in SimaticAI SDK resources which can be used in the user code,
after they are copied into the source folder of the pipeline component.
This can be done with the function
`simaticai.common.resources.copy_resource_to(f"{RESOURCE_NAME}", TARGET_FOLDER)`.

Example:
    from simaticai.common.resources import copy_resource_to
    copy_resource_to("ImageSet", "my_component_source_dir")

Currently supported resource names:
    - ImageSet: adds `imageset.py` resource file and its dependencies to the target directory.
"""
SIMATICAI_DEPENDENCIES = importlib_metadata.requires("simaticai") or ['opencv-python-headless>=4.9.0.80']
OPENCV_SPEC = [dep for dep in SIMATICAI_DEPENDENCIES if 'opencv-python-headless' in dep][0]

SIMATICAI_RESOURCES = {
    'ImageSet': {
        'path': 'payloads/imageset.py',
        'dependencies': ['numpy', OPENCV_SPEC]
    }
}

SIMATICAI_RESOURCE_KEYS = list(SIMATICAI_RESOURCES.keys())

def get_resource(resource_name: str):
    """
    Checks the availability of a SimaticAI SDK resource and retrieves information.

    Args:
        resource_name (str): Name of the SimaticAI SDK resource to be retrieved.
    Returns:
        dict: Information about the resource including 'path', 'dependencies', and 'source' file location.
    Raises:
        AssertionError: If the resource_name is not supported.
    """
    if resource_name not in SIMATICAI_RESOURCES:
        raise AssertionError(f"SimaticAI SDK resource '{resource_name}' is not supported.")

    resource_info = SIMATICAI_RESOURCES[resource_name]

    return {
        'path': resource_info['path'],
        'name': Path(resource_info['path']).name,
        'dependencies': resource_info['dependencies'],
        'source': module_resources.files("simaticai") / resource_info['path']
    }

def copy_resource_to(resource_name: str, component_directory: os.PathLike | str):
    """
    Copies a SimaticAI SDK resource file to the component directory.

    This method allows adding common SimaticAI SDK resource files such as `imageset.py` to a component.
    The method automatically adds the required dependencies for the resource file too.

    Args:
        resource_name (str): Name of the SimaticAI SDK resource to be copied. Currently supported only: 'ImageSet'
        component_directory (path-like): Root folder of your component's source code.
    Raises:
        AssertionError: If the resource_name is not supported.
    """
    resource = get_resource(resource_name)

    target_path = Path(component_directory) / resource['name']
    if target_path.exists():
        _logger.warning(f"Resource '{resource['name']}' is already added to target directory '{target_path}'.")
    else:
        _logger.warning(f"Adding SimaticAI SDK resource '{resource['name']}' to component directory '{component_directory}'. Creating file at '{target_path}'.")
        target_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(resource['source'], target_path)

    resource_dependencies = resource['dependencies']
    not_required = set()
    requirements_path = Path(component_directory, 'requirements.txt')
    if requirements_path.is_file():
        requirements = requirements_path.read_text(encoding='utf8').splitlines()
        requirements = [line.strip() for line in requirements if not line.strip().startswith('#')]
        for dependency in resource_dependencies:
            spec = pep508.parse_line(f"{dependency}")
            if any(spec.name in line for line in requirements):
                not_required.add(dependency)
    if len(not_required) < len(resource_dependencies):
        with requirements_path.open("a+", encoding="utf8") as req_file:
            req_file.write(f"\n# Additional dependencies required for '{resource_name}':")
            for dependency in set(resource_dependencies) - not_required:
                req_file.write(f"\n{dependency}")
    _logger.warning(f"Dependencies were added to {requirements_path}.")
    _logger.warning('Please make sure that every dependency version is compatible with your existing dependencies!')
