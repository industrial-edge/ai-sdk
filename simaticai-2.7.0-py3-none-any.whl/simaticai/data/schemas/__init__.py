"""
SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
SPDX-License-Identifier: MIT

This module contains the schema files used in validation methods.

These JSON schema files describe the configuration YAML files' schema
for AI Inference Server.
"""
