"""
SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
SPDX-License-Identifier: MIT

This module contains additional files for AI SDK.

These files are necessary for some functionalities of the SDK.
"""
