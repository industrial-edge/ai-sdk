"""
SPDX-FileCopyrightText: Copyright (C) 2025 Siemens AG
SPDX-License-Identifier: MIT

This module contains the VCAStream class, which generates image data streams
from a specified folder of images. The images are converted into the ImageSet format,
suitable for use on testing purposes.

The VCAStream class inherits from DataStream and provides an iterator that
yields ImageSet objects containing images in the specified format.

Example usage:
    vca_stream = VCAStream(data='/path/to/image/folder', variable_name='vision_payload', image_format='BayerRG8')
    with LocalPipelineRunner("MyPipeline-edge_1.zip") as runner:
        runner.run_pipeline(vca_stream)
"""

import os
import uuid

from pathlib import Path
from simaticai.testing.data_stream import DataStream
from simaticai.payloads.imageset import ImageDetails, ImageSet, ImageFormat

class VCAStream(DataStream):
    """
    This class creates a generator from a folder of images.

    The generate function returns a generator that walks over the image folder and converts
    each image into the specified format, BayerRG8 by default. The resulting object is in the
    ImageSet format, as if it were received from AI Inference Server.
    """

    def __init__(self, data: os.PathLike, variable_name: str = 'vision_payload', image_format: str | ImageFormat = 'BayerRG8', filter: str | None = None):
        """
        Creates a new VCAStream object

        Args:
            data (os.Pathlike): Path to the directory of images
            variable_name (str): Name of the variable to store the images (default: 'vision_payload')
            image_format (str): Supported image formats: 'BGR' (equivalently: 'BGR8'), 'RGB' (equivalently: 'RGB8'), 'BayerRG8' (default),
                'BayerGR8', 'BayerBG8', 'BayerGB8', 'Mono8', 'YUV422Packed', 'YUV422_YUYV_Packed'
            filter (rglob_pattern): Pattern to filter the images (see also: pathlib.rglob())
        """
        self.seq = 0
        self.data = data
        if filter is None or "" == filter.strip():
            self.filter = "**/*.[jJpP][pPnN][gGeE]*"
        else:
            self.filter = filter
        if variable_name is None or "" == variable_name.strip():
            self.variable_name = 'vision_payload'
        else:
            self.variable_name = variable_name

        if image_format is None:
            self.image_format = ImageFormat.BayerRG8
        else:
            try:
                self.image_format = ImageDetails._parse_image_format(image_format)
            except ValueError as err:
                raise AssertionError(str(err))
        
        self.camera_id = uuid.uuid4()
        self._iter_image_paths: list[Path] = []
        self._iter_current_index: int = 0

    def __iter__(self):
        """
        Initializes the iterator by collecting all image paths and resetting the index.

        Returns: self (the iterator object)
        """
        self._iter_image_paths = list(Path(self.data).rglob(self.filter))
        self._iter_current_index = 0
        return self

    def __next__(self):
        """
        Returns the next ImageSet from the image folder.

        Raises:
            StopIteration: When there are no more images to process.

        Returns: A dictionary containing the ImageSet variable.
        """
        if len(self._iter_image_paths) == 0:
            self.__iter__()

        if self._iter_current_index >= len(self._iter_image_paths):
            raise StopIteration

        image_path = self._iter_image_paths[self._iter_current_index]
        self._iter_current_index += 1
        return self._create_imageset(image_path)

    def _create_imageset(self, image_path):

        image_detail = ImageDetails.from_image(image_path=image_path, format=self.image_format)
        image_detail.id = f'VCA Stream : {image_detail.id}'
        image_detail.metadata = {"ptpstatus": "Disabled", "ptptimestamp": "0"}
        image_detail.seq = self.seq
        self.seq += 1
        
        imageset = ImageSet(
            version='1',
            cameraid=str(self.camera_id),
            timestamp=image_detail.timestamp,
        )
        imageset.add_image(image_detail)

        result = {self.variable_name: imageset.to_dict()}
        return result
