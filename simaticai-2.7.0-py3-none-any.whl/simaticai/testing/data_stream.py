# SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
# SPDX-License-Identifier: MIT

class DataStream:
    """
    Base class for datastream generators
    """

    def __iter__(self):
        """
        Empty generator method for child classess to implement.
        """
        raise NotImplementedError('Child classes must implement this method.')
