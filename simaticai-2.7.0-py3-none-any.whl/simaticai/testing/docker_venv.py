"""
SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
SPDX-License-Identifier: MIT

This module provides a base class for creating and managing Docker containers
with Python virtual environments. It is designed to be used in a context where
Docker is available and the user has the necessary permissions to create and
manage containers.
"""
import logging
from pathlib import Path
import subprocess

logging.basicConfig()
_logger = logging.getLogger(__name__)
_logger.setLevel(logging.INFO)


class VesselBaseDocker:
    is_vessel: bool = False  # True when running in a Docker container
    python_3_11: str = 'python'
    python_3_12: str = 'python'

    def __init__(self):
        if Path("/.ai_sdk_docker").is_file():
            self.is_vessel = True
            self.python_default = 'python3.11'
            self.python_3_11 = 'python3.11'
            self.python_3_12 = 'python3.12'

    def _create_venv(self, path: str, version: str):
        """
        Creates a virtual environment in which the given component can run.

        Args:
            path (str): Path to the virtual environment.
            version (str): Python version to use for the virtual environment.
        """

        context_dir = Path(path) / ".venv"
        python_path = context_dir / "bin" / "python"

        match version:
            case "3.11":
                python = self.python_3_11
            case "3.12":
                python = self.python_3_12
            case _:
                python = self.python_default
        _logger.info(f"Creating virtual environment for Python '{version}' in '{path}/.venv' with Python {python}...")

        command = [
            python,
            "-m", "venv", str(context_dir),
            "--copies"
        ]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode != 0:
            _logger.error(f"Error creating virtual environment: {result.stderr}")
            raise RuntimeError(f"Error creating virtual environment: {result.stderr}")

        return context_dir.resolve(), python_path.resolve()
