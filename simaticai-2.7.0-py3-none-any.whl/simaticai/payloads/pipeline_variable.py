"""
SPDX-FileCopyrightText: Copyright (c) 2024 Siemens AG
SPDX-License-Identifier: MIT

Contains classes for defining pipeline variables and parameters, including their connections and mappings.
PipelineVariable links a component's variable to a connection, while PipelineParameter defines parameters that can be set runtime.
PipelineParameter can be topic-based, allowing dynamic updates via messaging topics.
SecretPipelineParameter is a specialized parameter type for handling sensitive information.
"""

import re
from dataclasses import dataclass, field
from typing import Optional

from .connection import Connection

reserved_names = ["timestamp"]


class MappableMixin:
    """
    Mixin class providing mapping functionality for preconfiguration of Pipeline Variables and Parameters.

    Attributes:
        connection (Optional[Connection]): The connection associated with the variable.
        name (Optional[str]): The tag or camera name to map to.
        mapping (Optional[str]): The mapping to map to.

    Methods:
        add_mapping(tagName: Optional[str], cameraName: Optional[str], mapping: Optional[str]) -> Self:
            Adds mapping information to the variable.
        add_connection(connection: Connection) -> Self:
            Adds a connection to the variable.
        add_mapping_with_connector(connection: Connection, tagName: Optional[str], cameraName: Optional[str], mapping: Optional[str]) -> Self:
            Adds both mapping information and a connection to the variable.
        _to_config_mapping() -> dict:
            Returns the mapping configuration as a dictionary.

    """

    def __setattr__(self, name, value):
        """Handle setting of mapping-related attributes."""
        match name:
            case "connection":
                if value is not None and not isinstance(value, Connection):
                    raise ValueError("ERROR! 'connection' must be an instance of Connection or None.")
            case "tagName" | "cameraName" | "mapping":
                if hasattr(self, 'topicBased') and value is not None:
                    self.topicBased = True
                if name == "cameraName" and value is not None:
                    self.tagName = value
            case _:
                # Other attributes are handled by the dataclass
                pass

        super().__setattr__(name, value)

    def add_mapping(self, *, tagName: Optional[str] = None, cameraName: Optional[str] = None, mapping: Optional[str] = None):
        """
        Adds mapping information to the variable.
        Property 'tagName' is supposed to be used with message queues, while 'cameraName' with Vision Connector Application.
        In case you define both, only 'tagName' will be used and preconfigured.


        Args:
            tagName (Optional[str]): The tag name to map to.
            cameraName (Optional[str]): The camera name to map to.
            mapping (Optional[str]): The topic or camera id to map to.
        """
        self.tagName = tagName or cameraName
        self.mapping = mapping
        return self

    def add_connection(self, connection: Connection):
        """
        Adds a connection to the variable.
        Args:
            connection (Connection): The connection to add.
        """
        self.connection = connection
        return self

    def add_mapping_with_connection(self, connection: Connection, *, tagName: Optional[str] = None, cameraName: Optional[str] = None, mapping: Optional[str] = None):
        """
        Adds both mapping information and a connection to the variable.
        Property 'tagName' is supposed to be used with message queues, while 'cameraName' with Vision Connector Application.
        In case you define both, only 'tagName' will be used and preconfigured.

        Args:
            connection (Connection): The connection to add.
            tagName (Optional[str]): The tag name to map to.
            cameraName (Optional[str]): The camera name to map to.
            mapping (Optional[str]): The topic or camera id to map to.
        """
        self.add_connection(connection)
        self.add_mapping(tagName=tagName, cameraName=cameraName, mapping=mapping)
        return self

    def __mappable_dict__(self) -> dict:
        """Returns the mapping configuration as a dictionary."""
        json_dict = {}

        if self.connection is not None:
            for k, v in self.connection.__dict__().items():
                json_dict[k] = v

        if self.tagName is not None:
            json_dict['tagName'] = self.tagName
        if self.mapping is not None:
            json_dict['topic'] = self.mapping

        return json_dict


@dataclass
class PipelineVariable(MappableMixin):
    """
    Represents a variable in a pipeline, linking a component's variable to a connection and optional mapping.
    For IE Vision connections, cameraName should be defined, otherwise tagName is preferred.

    Attributes:
        componentName (str): The name of the component the variable belongs to.
        variableName (str): The name of the variable.

        connection (Optional[Connection]): The connection associated with the variable.
        tagName (Optional[str]): The tag name to map to.
        cameraName (Optional[str]): The camera name to map to. Used only via IE_Vision connection.
        mapping (Optional[str]): The topic or camera id to map to.
    """
    componentName: str
    variableName: str

    # Mixin fields as dataclass fields
    connection: Optional[Connection] = field(default=None)
    tagName: Optional[str] = field(default=None)
    cameraName: Optional[str] = field(default=None)
    mapping: Optional[str] = field(default=None)

    def __getitem__(self, item):
        return getattr(self, item)

    def __setattr__(self, name, value):
        """
        Setter for all attributes
        """
        match name:
            case "componentName":
                if re.match("^[a-zA-Z0-9_-]+$", value) is None:
                    raise ValueError(f"ERROR! Invalid name '{value}'. Only alphanumeric characters and underscores are allowed.")
            case "variableName":
                if re.match("^[a-zA-Z0-9_-]+$", value) is None:
                    raise ValueError(f"ERROR! Invalid name '{value}'. Only alphanumeric characters and underscores are allowed.")
                if value in reserved_names:
                    raise ValueError(f"ERROR! '{value}' is a reserved name and cannot be used as variable name.")
            case _:
                # Let the mixin handle mapping attributes
                pass

        super().__setattr__(name, value)

    def __dict__(self, component_io_list: list) -> dict:
        json_dict = {
            "name": self.variableName,
            "type": component_io_list[self.variableName]['type']
        }

        json_dict.update(self.__mappable_dict__())

        return json_dict


@dataclass
class PipelineParameter(MappableMixin):
    name: str
    defaultValue: Optional[str] = None
    dtype: Optional[str] = None  # 'String', 'Integer', 'Float', 'Boolean'
    description: Optional[str] = None
    topicBased: Optional[bool] = False
    valueTopic: Optional[str] = None

    # Mixin fields as dataclass fields
    connection: Optional[Connection] = field(default=None)
    tagName: Optional[str] = field(default=None)
    mapping: Optional[str] = field(default=None)

    def __post_init__(self):
        # Validate if the topicBased flag is False, then valueTopic, connection, tag, and topic should not be set
        if not self.topicBased and (self.valueTopic is not None or self.connection is not None or self.tagName is not None or self.mapping is not None):
            raise ValueError("ERROR! 'valueTopic', 'connection', 'tag', and 'topic' must be None when 'topicBased' is False.")
        if self.dtype != _get_is_type(type(self.defaultValue)):
            raise ValueError(f"'The given value type does not match the type of defaultValue: '{self.defaultValue}'")

    def __setattr__(self, name, value):
        """
        Setter for all attributes
        """
        match name:
            case "name":
                _check_name_validity(value)
            case "dtype":
                if value is None:
                    return
                elif value not in ['String', 'Integer', 'Double', 'Boolean']:
                    raise ValueError("ERROR! 'dtype' must be one of 'String', 'Integer', 'Double', 'Boolean', or None.")
            case "defaultValue":
                dtype = _get_is_type(type(value))
                if dtype is None:
                    raise ValueError("ERROR! 'dtype' must be one of 'String', 'Integer', 'Double', 'Boolean', or None.")
                self.dtype = dtype
            case "description":
                _check_description_validity(value)
            case "topicBased":
                if not isinstance(value, bool):
                    raise ValueError("Type of the given `topic_based` parameter is not `bool`")
            case "valueTopic":
                if not (value is None or value == ""):
                    self.topicBased = True
            case _:
                # Let the mixin handle mapping attributes
                pass

        super().__setattr__(name, value)

    def __param_dict__(self) -> dict:
        json_dict = {
            'name': self.name,
            'defaultValue': self.defaultValue,
            'dtype': self.dtype
        }

        json_dict.update(self.__mappable_dict__())

        json_dict['type'] = json_dict.pop('dtype', None)
        if self.topicBased:
            json_dict['topicBased'] = True
            json_dict['valueTopic'] = json_dict.pop('topic', None)

        return json_dict


def _get_is_type(py_type: type) -> Optional[str]:
    match py_type.__name__:
        case "str":
            return "String"
        case "int":
            return "Integer"
        case "float":
            return "Double"
        case "bool":
            return "Boolean"
        case _:
            return None


def _check_name_validity(name: str):
    if re.match("^[a-zA-Z0-9_-]+$", name) is None:
        raise ValueError(f"ERROR! Invalid name '{name}'. Only letters, digits, underscores, and hyphens are allowed.")
    if name.startswith("__AI_IS_"):
        raise ValueError("Pipeline parameters with `__AI_IS_` prefix should not be specified in the pipeline configuration. However, the entrypoint script should be able to handle them in the `update_parameters` method.")
    if name in reserved_names:
        raise ValueError(f"ERROR! '{name}' is a reserved name and cannot be used as variable name.")


def _check_description_validity(description: str):
    if description is not None and (not isinstance(description, str) or len(description) > 60 or len(description) < 3):
        raise ValueError("ERROR! 'description' must be a string between 3 and 60 characters.")


@dataclass(frozen=True)
class SecretPipelineParameter:
    """
    Represents a secret pipeline parameter for handling sensitive information.
    Cannot be modified after creation.

    Attributes:
        name (str): The name of the secret parameter.
        description (Optional[str]): An optional description of the secret parameter.
        defaultValue (str): Pipeline parameters must have a default value, which is an empty string for secret parameters.
        dtype (str): The data type of the secret parameter is always "Secret".
    """

    name: str
    description: Optional[str] = None
    defaultValue: str = field(init=False, default="")
    dtype: str = field(init=False, default="Secret")

    def __post_init__(self):
        _check_name_validity(self.name)
        _check_description_validity(self.description)

    def __param_dict__(self) -> dict:
        json_dict = {
            'name': self.name,
            'defaultValue': "",
            'type': self.dtype
        }
        return json_dict
