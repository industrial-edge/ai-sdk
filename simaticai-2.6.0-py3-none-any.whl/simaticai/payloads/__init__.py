#  SPDX-FileCopyrightText: 2025 Siemens AG
#  SPDX-License-Identifier: MIT

from .connection import Connection, ConnectionTypeAndPayloadFormat
from .pipeline_variable import PipelineVariable, PipelineParameter

__all__ = [
    "Connection", "ConnectionTypeAndPayloadFormat",
    "PipelineVariable", "PipelineParameter"
]
