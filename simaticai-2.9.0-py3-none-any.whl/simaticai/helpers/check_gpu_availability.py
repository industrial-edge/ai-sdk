"""
SPDX-FileCopyrightText: Copyright (C) 2025 Siemens AG
SPDX-License-Identifier: MIT

This script checks for GPU availability by attempting to import TensorFlow and PyTorch and checking if they can access the GPU.
"""

import sys

import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def check_tensorflow_gpu():
    try:
        import tensorflow as tf
        logger.info(f"TensorFlow version {tf.__version__} detected.")
        if len(tf.config.list_physical_devices('GPU')) > 0:
            logger.info("GPU is accessible (TensorFlow).")
            return True
        else:
            logger.warning("GPU is NOT accessible by TensorFlow.")
            return False
    except ImportError:
        logger.info("TensorFlow not installed or accessible.")
        return None

def check_pytorch_gpu():
    try:
        import torch
        logger.info(f"PyTorch version {torch.__version__} detected.")
        if torch.cuda.is_available():
            logger.info("GPU is accessible (PyTorch).")
            return True
        else:
            logger.warning("GPU is NOT accessible by PyTorch.")
            return False
    except ImportError:
        logger.info("PyTorch not installed or accessible.")
        return None

tf_gpu = check_tensorflow_gpu()
torch_gpu = check_pytorch_gpu()

if tf_gpu is True or torch_gpu is True:
    logger.info("GPU is available and accessible.")
    sys.exit(0)  # Exit with success code
elif tf_gpu is False or torch_gpu is False:
    logger.warning("GPU is NOT accessible by either TensorFlow or PyTorch.")
    sys.exit(1)  # Exit with failure code
else:
    logger.warning("GPU availability could not be determined. Neither TensorFlow nor PyTorch is installed or accessible.")
    sys.exit(1)  # Exit with failure code
