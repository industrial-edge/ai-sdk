"""
SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
SPDX-License-Identifier: MIT

Helpers.

This module contains functionality that does not belong to the main domain of the `simaticai` module.
"""

import hashlib
import os
import re
from pathlib import Path
from datetime import datetime, timezone

def calc_sha(file_path: str | os.PathLike) -> str:
    """Calculate SHA256 hash of a file.

    Args:
        file_path: Path to the file to hash.

    Returns:
        Hexadecimal string representation of the SHA256 hash.
    """
    file_path = Path(file_path)
    data_buffer = memoryview(bytearray(262144))
    sha_generator  = hashlib.sha256()
    with open(file_path, 'rb', buffering=0) as file:
        for n in iter(lambda: file.readinto(data_buffer), 0):
            sha_generator.update(data_buffer[:n])
    return sha_generator.hexdigest()

def compare_versions(a: str, b: str, *, ignore_patch: bool = False) -> int:
    """Compare two version strings.

    Args:
        a: First version string (e.g., '1.2.3').
        b: Second version string (e.g., '1.2.4').

    Returns:
        Negative if a < b, zero if a == b, positive if a > b.
    """
    a =  re.sub(r"^([0-9.]*).*$", "\\1", f"{a}")
    b =  re.sub(r"^([0-9.]*).*$", "\\1", f"{b}")
    a_major, a_minor, a_patch, * _ = [int(v.strip() or 0) for v in f"{a}...".split(".")]
    b_major, b_minor, b_patch, * _ = [int(v.strip() or 0) for v in f"{b}...".split(".")]
    if a_major != b_major:
        return a_major - b_major
    if a_minor != b_minor:
        return a_minor - b_minor
    if not ignore_patch:
        return a_patch - b_patch
    return 0

def increment_version(version: str | int) -> str:
    """Increment the version number.

    Args:
        version: Version string (e.g., '1.2.3') or integer.

    Returns:
        Version string with the last component incremented by 1.
    """
    versions = [int(v.strip() or 0) for v in f"{version}".split(".")]
    versions[-1] += 1
    return ".".join(str(v) for v in versions)

def timestamp_aiis_compatible() -> str:
    """Generate current UTC timestamp in AIIS-compatible format.

    Returns:
        ISO 8601 formatted UTC timestamp string (YYYY-MM-DDTHH:MM:SSZ).
    """
    return str(datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
