# SPDX-FileCopyrightText: Copyright (C) 2024 Siemens AG
# SPDX-License-Identifier: MIT

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class ConnectionTypeAndPayloadFormat(Enum):
    """
    Enum for predefined connection on AI Inference Server.
    The Attributes of the enum are tuples with the Type and Payload Format supported on AI Inference Server.

    Attributes:
        Databus_String (tuple): ("databus", "String")
        Databus_SIMATICv1 (tuple): ("databus", "S7Json")

        External_Databus (tuple): ("mqtt", "String")

        IE_Vision (tuple): ("vision", "VisionConnectorRaw")

        ZMQ_Vision (tuple): ("zmq", "VisionConnectorRaw")
        ZMQ_Multipart (tuple): ("zmq", "ZmqPayload")
        ZMQ_Multipart_with_Metadata (tuple): ("zmq", "ZmqImageOutput")

        Realtime_Information_Backbone (tuple): ("rib", "RIBPayload")
    """

    Databus_String = ("databus", "String")
    """
    Databus String or Json
    """

    Databus_SIMATICv1 = ("databus", "S7Json")
    """
    SIMATIC v1 (S7, S7+, OPC-UA, PROFINET IO)
    """

    External_String = ("mqtt", "String")
    """
    External Databus String
    """

    IE_Vision = ("vision", "VisionConnectorRaw")
    """
    IE Vision Connector (High throughput, ZMQ Based, Multipart)
    """

    ZMQ_Vision  = ("zmq", "VisionConnectorRaw")
    """
    Zero Message Queue Vision Connector Raw (Vision payload)
    """

    ZMQ_Multipart     = ("zmq", "ZmqPayload")
    """
    Zero Message Queue Internal multipart message (Topic, binary data or string)
    """

    ZMQ_Multipart_with_Metadata       = ("zmq", "ZmqImageOutput")
    """
    Zero Message Queue Internal multipart message (Topic, metadata, binary)
    """

    Realtime_Information_Backbone = ("rib", "RIBPayload")
    """
    Real-time Information Backbone
    """

@dataclass
class Connection:
    """
    Represents a connection with a name and an optional predefined combination of connection type and payload format.

    Attributes:
        name (str): The name of the connection.
        cptype (Optional[ConnectionTypeAndPayloadFormat]): The connection type and payload format, represented as an Enum.

    Methods:
        __setattr__(name, value):
            Custom attribute setter that validates attribute assignment.
            - 'name': Accepts any value.
            - 'cptype': Must be None or an instance of ConnectionTypeAndPayloadFormat.
            - Any other attribute: Raises ValueError.

        __dict__():
            Returns a dictionary representation of the connection, including:
            - 'connectorName': The name of the connector.
            - 'connectorType': The type of the connector (if cptype is set).
            - 'payloadType': The payload type (if cptype is set).
    """

    name: str
    cptype: Optional[ConnectionTypeAndPayloadFormat] = None

    def __setattr__(self, name, value):
        """
        Setter for all attributes
        """
        match name:
            case "name":
                pass
            case "cptype":
                if value is not None and not isinstance(value, ConnectionTypeAndPayloadFormat):
                    raise ValueError("ERROR! 'type' must be an instance of ConnectionTypeAndPayloadFormat Enum.")
            case _:
                raise ValueError(f"ERROR! Unknown attribute '{name}' for connector '{self.name}'.")
        super(self.__class__, self).__setattr__(name, value)

    def __dict__(self):
        connection_dict = {
            "connectorName": self.name
        }
        if self.cptype is not None:
            connection_dict["connectorType"] = self.cptype.value[0]
            connection_dict["payloadType"] = self.cptype.value[1]

        return connection_dict

# Example usage:
# connector = Connector(name="test", cptype=CPType.S7JSON)
# print(connector.__dict__())

SUPPORTED_TYPES_BY_CONNECTION = {
    ConnectionTypeAndPayloadFormat.Databus_String: ["String"],
    ConnectionTypeAndPayloadFormat.Databus_SIMATICv1: [
        "Boolean", "BooleanArray",
        "Integer", "IntegerArray",
        "Double", "DoubleArray",
        "String", "StringArray",
        "Bool", "BoolArray",
        "UInt8", "UInt8Array",
        "UInt16", "UInt16Array",
        "UInt32", "UInt32Array",
        "UInt64", "UInt64Array",
        "Int8", "Int8Array",
        "Int16", "Int16Array",
        "Int32", "Int32Array",
        "Int64", "Int64Array",
        "Float32", "Float32Array",
        "Float64", "Float64Array"
    ],
    ConnectionTypeAndPayloadFormat.External_String: ["String"],
    ConnectionTypeAndPayloadFormat.IE_Vision: ["ImageSet"],
    ConnectionTypeAndPayloadFormat.ZMQ_Vision: ["ImageSet"],
    ConnectionTypeAndPayloadFormat.ZMQ_Multipart: ["String", "Binary"],
    ConnectionTypeAndPayloadFormat.ZMQ_Multipart_with_Metadata: ["Object"],
    ConnectionTypeAndPayloadFormat.Realtime_Information_Backbone: [
        "Boolean", "BooleanArray",
        "Integer", "IntegerArray",
        "Double", "DoubleArray",
        "Bool", "BoolArray",
        "UInt8", "UInt8Array",
        "UInt16", "UInt16Array",
        "UInt32", "UInt32Array",
        "UInt64", "UInt64Array",
        "Int8", "Int8Array",
        "Int16", "Int16Array",
        "Int32", "Int32Array",
        "Int64", "Int64Array",
        "Float32", "Float32Array",
        "Float64", "Float64Array"
    ]
}
