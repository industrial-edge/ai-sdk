"""
SPDX-FileCopyrightText: Copyright (C) 2025 Siemens AG
SPDX-License-Identifier: MIT

This module defines the ImageDetails and ImageSet data structures for handling image payloads
in the context of AI Inference Server communication.
It includes functionality for parsing and formatting timestamps, converting image formats,
and serializing/deserializing image data.

Examples:
    - Creating an ImageDetails object from an image file:
        image_details = ImageDetails.from_image("path/to/image.jpg", format="RGB8")

    - Creating an ImageSet and adding images:
        image_set = ImageSet()
        image_set.add_image(image_details)
        images_set.add_image(ImageDetails.from_image("path/to/another_image.png", format="Mono8"))

    - Converting a BGR image to a different format:
        converted_image, height, width = ImageDetails.convert_image_from_BGR(bgr_image, "Mono8")

    - Creating an ImageSet from a dictionary payload:
        image_set = ImageSet.from_dict(payload_dict)

    - Serializing an ImageSet to a dictionary:
        payload_dict = image_set.to_dict()

Vision Payload Specification
https://docs.eu1.edge.siemens.cloud/apis_and_references/apis/point-to-point/VisionPayloadspecification_V1-0-0.html#vision-connector-image-format
However, the above documentation is incomplete. The following are the

Required fields for ImageSet, based on AI Inference Server source
    {"version", FieldType::String},
    {"cameraid", FieldType::String},
    {"timestamp", FieldType::String},
    {"detail", FieldType::StructArray} };

Required fields for ImageDetails, based on AI Inference Server source:
    {"id", FieldType::String},
    {"seq", FieldType::Integer},
    {"format", FieldType::String},
    {"image", FieldType::Binary} };
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List
from enum import Enum
import uuid
import re
import cv2
import numpy as np
from pathlib import Path

DATE_TIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%f%z"

def parse_aiis_timestamp(timestamp_str: str | None) -> datetime:
    """Parses a timestamp string from AI Inference Server format to a datetime object.
    Args:
        timestamp_str (str | None): Timestamp string in AI Inference Server format.
    Returns: datetime: Parsed datetime object.
    """
    if timestamp_str is None or "" == timestamp_str.strip():
        return datetime.now(timezone.utc)
    timestamp_str = re.sub(r'[zZ]$', '+00:00', timestamp_str)
    return datetime.strptime(timestamp_str, DATE_TIME_FORMAT)

def format_aiis_timestamp(timestamp: datetime | None) -> str:
    """Formats a datetime object to a timestamp string in AI Inference Server format.
    Args:
        timestamp (datetime | None): Datetime object to format.
    Returns: str: Formatted timestamp string.
    """
    if timestamp is None:
        timestamp = datetime.now(timezone.utc)
    return re.sub(r'\+.*$','', timestamp.isoformat(timespec='milliseconds')) + 'Z'

class ImageFormat(Enum):
    """Enumeration of supported image formats.
    To extend supported formats, update the ImageDetails conversion methods accordingly.
    """
    RGB8 = "RGB8"
    BGR8 = "BGR8"
    YUV422Packed = "YUV422Packed"
    YUV422_YUYV_Packed = "YUV422_YUYV_Packed"
    Mono8 = "Mono8"
    BayerRG8 = "BayerRG8"
    BayerGR8 = "BayerGR8"
    BayerBG8 = "BayerBG8"
    BayerGB8 = "BayerGB8"

@dataclass
class ImageDetails:
    """Data structure representing the details of a single image in an ImageSet payload.
    Represents the details of a single image in an ImageSet payload.
    Fields:
        id (str): Unique identifier for the image.
        width (int): Width of the image in pixels.
        height (int): Height of the image in pixels.
        seq (int): Sequence number of the image.
        timestamp (datetime): Timestamp when the image was captured.
        metadata (dict): Additional metadata associated with the image.
        format (ImageFormat): Format of the image.
        image (bytes): Binary data of the image.
    """

    id: str
    width: int
    height: int

    seq: int = field(default=0)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict = field(default_factory=dict)

    format: ImageFormat = field(default=ImageFormat.RGB8)
    image: bytes = field(default=b"")

    def __post_init__(self):
        assert isinstance(self.id, str)
        assert isinstance(self.timestamp, datetime)
        assert isinstance(self.width, int) and self.width > 0
        assert isinstance(self.height, int) and self.height > 0
        assert isinstance(self.format, ImageFormat) and self.format in ImageFormat.__members__.values()
        assert isinstance(self.image, bytes) and len(self.image) > 0

    @staticmethod
    def _parse_image_format(format: str | ImageFormat | None = None) -> ImageFormat:
        match format:
            case None:
                return ImageFormat.RGB8
            case ImageFormat():
                return format
            case str() if format in ImageFormat.__members__.keys():
                return ImageFormat[format]
        _supported_image_formats = [format.value for format in ImageFormat.__members__.values()]
        raise ValueError(f"ERROR Provided image format '{format}' is not supported. image_format must be one of {_supported_image_formats}")

    @staticmethod
    def from_image(image_path: Path | str, format: ImageFormat | str | None = None) -> 'ImageDetails':
        """Creates an ImageDetails object from an image file.
        Args:
            image_path (Path | str): Path to the image file.
            format (ImageFormat | str | None): Desired image format (default: RGB8).
        Raises:
            ValueError: If the image file is not found or cannot be read.
        Returns: ImageDetails: Created ImageDetails object.
        """
        format = ImageDetails._parse_image_format(format)

        image_path = Path(image_path)
        image = cv2.imread(str(image_path))
        if image is None:
            raise ValueError(f"Image file {image_path} not found")

        res_image, height, width = ImageDetails.convert_image_from_BGR(image, format)
        return ImageDetails(
            id=image_path.name,
            timestamp=datetime.now(timezone.utc),
            width=width,
            height=height,
            format=format,
            image=res_image
        )

    @staticmethod
    def _bgr_to_bayer(bgr_image: np.ndarray, bayer_order: str) -> np.ndarray:
        (height, width) = bgr_image.shape[:2]
        bayer_image = np.zeros((height, width), dtype=np.uint8)

        BLUE, GREEN, RED = 0, 1, 2
        match bayer_order:
            case 'BayerRG8':
                channels = (RED, GREEN, GREEN, BLUE)
            case 'BayerGR8':
                channels = (GREEN, RED, BLUE, GREEN)
            case 'BayerBG8':
                channels = (BLUE, GREEN, GREEN, RED)
            case 'BayerGB8':
                channels = (GREEN, BLUE, RED, GREEN)
            case _:
                raise ValueError(f"Unsupported bayer order: {bayer_order}")

        top_left_ch, top_right_ch, bottom_left_ch, bottom_right_ch = channels
        bayer_image[0::2, 0::2] = bgr_image[0::2, 0::2, top_left_ch]
        bayer_image[0::2, 1::2] = bgr_image[0::2, 1::2, top_right_ch]
        bayer_image[1::2, 0::2] = bgr_image[1::2, 0::2, bottom_left_ch]
        bayer_image[1::2, 1::2] = bgr_image[1::2, 1::2, bottom_right_ch]
        return bayer_image

    @staticmethod
    def convert_image_from_BGR(bgr_image: np.ndarray, target_format: str | ImageFormat | None = None) -> tuple[bytes, int, int]:
        """
        Converts a BGR image to the specified target format.
        Args:
            bgr_image (np.ndarray): Input image in BGR format.
            target_format (str | ImageFormat): Target image format.
        Raises:
            ValueError: If the target format is unsupported.
        Returns: A tuple containing the converted image as bytes, height, and width.
        """

        _target_format: ImageFormat = ImageDetails._parse_image_format(target_format)

        match _target_format:
            case "BGR8" | ImageFormat.BGR8:
                res_image = bgr_image
            case "RGB8" | ImageFormat.RGB8:
                res_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2RGB)
            case "Mono8" | ImageFormat.Mono8:
                res_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2GRAY)
            case "BayerRG8" | ImageFormat.BayerRG8:
                res_image = ImageDetails._bgr_to_bayer(bgr_image, "BayerRG8")
            case "BayerGR8" | ImageFormat.BayerGR8:
                res_image = ImageDetails._bgr_to_bayer(bgr_image, "BayerGR8")
            case "BayerBG8" | ImageFormat.BayerBG8:
                res_image = ImageDetails._bgr_to_bayer(bgr_image, "BayerBG8")
            case "BayerGB8" | ImageFormat.BayerGB8:
                res_image = ImageDetails._bgr_to_bayer(bgr_image, "BayerGB8")
            case "YUV422Packed" | ImageFormat.YUV422Packed:
                # COLOR_BGR2YUV_Y422 is the 4:2:2 sampling format of YUV, with coefficients correspond to the BT.601 standard.
                # After ravel() it becomes a packed format, where the order of the channels is UYVY.
                res_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2YUV_Y422)
            case "YUV422_YUYV_Packed" | ImageFormat.YUV422_YUYV_Packed:
                # Same as the above but with YUYV order.
                res_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2YUV_YUYV)
            case _:
                raise ValueError(f"Unsupported target format: {target_format}")
        height, width = res_image.shape[:2]
        res_image = res_image.ravel().tobytes()
        return res_image, height, width

    @staticmethod
    def from_dict(data: dict):
        """
        Creates an ImageDetails object from the details of a given ImageSet payload.

        Args:
            data (dict): Dictionary containing image details
        Raises:
            ValueError: If there is an error parsing the image details
        Returns: ImageDetails: Parsed ImageDetails object
        """
        try:
            details = ImageDetails(
                id          =   data.get("id", f"simaticai-image-{datetime.now().timestamp()}"),
                seq         =   data.get("seq", 0),
                timestamp   =   parse_aiis_timestamp(data.get("timestamp")),
                format      =   ImageFormat[data.get("format", "RGB8")],
                width       =   data.get("width", 0),
                height      =   data.get("height", 0),
                metadata    =   data.get("metadata", {}),
                image       =   data.get("image", b"")
            )
        except Exception as e:
            raise ValueError(f"Error parsing image details: {repr(e)}")
        return details

    def to_dict(self) -> dict:
        """
        Converts the ImageDetails object to a dictionary.

        Returns:
            dict: Dictionary representation of the ImageDetails object.
        """
        return {
            "id": self.id,
            "seq": self.seq,
            "timestamp": format_aiis_timestamp(self.timestamp),
            "format": self.format.value,
            "width": self.width,
            "height": self.height,
            "metadata": self.metadata,
            "image": self.image
        }

    def update_image(self, image: np.ndarray, image_format: ImageFormat):
        """
        Updates the image data and format of the ImageDetails object.
        Args:
            image (np.ndarray): New image data as a NumPy array.
            image_format (ImageFormat): New image format.
        """
        self.format = image_format
        self.height = image.shape[0]
        self.width = image.shape[1]
        self.image = image.ravel().tobytes()

    def get_image_array(self) -> np.ndarray:
        """Returns the image as a NumPy array based on its format.
        Raises:
            ValueError: If the image format is unsupported.
        Returns: np.ndarray: Image as a NumPy array.
        """
        image = self.image
        image = np.frombuffer(image, dtype=np.uint8)
        match self.format:
            case ImageFormat.RGB8 | ImageFormat.BGR8:
                image = image.reshape(self.height, self.width, 3)
            case ImageFormat.Mono8 | ImageFormat.BayerRG8 | ImageFormat.BayerGR8 | ImageFormat.BayerBG8 | ImageFormat.BayerGB8:
                image = image.reshape(self.height, self.width)
            case ImageFormat.YUV422Packed | ImageFormat.YUV422_YUYV_Packed:
                image = image.reshape(self.height, self.width, 2)
            case _:
                raise ValueError(f"Unsupported image format: {self.format}")
        return image

    def get_image_rgb(self) -> np.ndarray:
        """Returns the image converted to RGB format as a NumPy array.
        Raises:
            ValueError: If the image format is unsupported.
        Returns: np.ndarray: Image in RGB format as a NumPy array.
        """
        image = self.get_image_array()
        match self.format:
            case ImageFormat.Mono8:
                return cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
            case ImageFormat.RGB8:
                return image
            case ImageFormat.BGR8:
                return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            case ImageFormat.BayerRG8:
                return cv2.cvtColor(image, cv2.COLOR_BayerRGGB2RGB)
            case ImageFormat.BayerGR8:
                return cv2.cvtColor(image, cv2.COLOR_BayerGRBG2RGB)
            case ImageFormat.BayerBG8:
                return cv2.cvtColor(image, cv2.COLOR_BayerBGGR2RGB)
            case ImageFormat.BayerGB8:
                return cv2.cvtColor(image, cv2.COLOR_BayerGBRG2RGB)
            case ImageFormat.YUV422Packed:
                return cv2.cvtColor(image, cv2.COLOR_YUV2RGB_Y422)
            case ImageFormat.YUV422_YUYV_Packed:
                return cv2.cvtColor(image, cv2.COLOR_YUV2RGB_YUYV)
            case _:
                raise ValueError(f"Unsupported image format: {self.format}")


@dataclass
class ImageSet:
    """Data structure representing an ImageSet payload containing multiple images.
    Fields:
        version (str): Version of the ImageSet payload.
        cameraid (str): Unique identifier for the camera.
        timestamp (datetime): Timestamp when the ImageSet was created.
        detail (List[ImageDetails]): List of ImageDetails objects representing the images in the set.
        count (int): Number of images in the ImageSet.
    """

    version: str = field(default="1.0")
    cameraid: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    detail: List[ImageDetails] = field(default_factory=list)

    count: int = field(default=0)

    def __post_init__(self):
        self.count = len(self.detail)

    def add_image(self, image: ImageDetails):
        """Adds an ImageDetails object to the ImageSet.
        Args:
            image (ImageDetails): ImageDetails object to add.
        """
        self.detail.append(image)
        self.count += 1

    def get_image_array(self, index: int = 0) -> np.ndarray:
        """Returns the image at the specified index as a NumPy array.
        Args:
            index (int): Index of the image to retrieve (default: 0).
        Raises:
            IndexError: If the index is out of range.
        Returns: np.ndarray: Image as a NumPy array.
        """
        if index < 0 or index >= len(self.detail):
            raise IndexError("Index out of range")

        image = self.detail[index].get_image_array()

        return image

    def get_image_rgb(self, index: int = 0) -> np.ndarray:
        """Returns the image at the specified index converted to RGB format as a NumPy array.
        Args:
            index (int): Index of the image to retrieve (default: 0).
        Raises:
            IndexError: If the index is out of range.
        Returns: np.ndarray: Image in RGB format as a NumPy array.
        """
        if index < 0 or index >= len(self.detail):
            raise IndexError("Index out of range")

        return self.detail[index].get_image_rgb()

    def to_dict(self):
        """Converts the ImageSet object to a dictionary.
        Returns:
            dict: Dictionary representation of the ImageSet object.
        """
        return {
            "version": self.version,
            "count": self.count,
            "cameraid": str(self.cameraid),
            "timestamp": format_aiis_timestamp(self.timestamp),
            "detail": [image.to_dict() for image in self.detail]
        }

    @staticmethod
    def from_dict(data: dict):
        """Creates an ImageSet object from a dictionary payload.
        Args:
            data (dict): Dictionary containing ImageSet data.
        Raises:
            ValueError: If there is an error parsing the ImageSet data.
        Returns: ImageSet: Parsed ImageSet object.
        """
        detail = data.get("detail", [])
        return ImageSet(
            version=data.get("version", "1.0"),
            count=data.get("count", len(detail)),
            cameraid=data.get("cameraid", str(uuid.uuid4())),
            timestamp=parse_aiis_timestamp(data.get("timestamp")),
            detail=[ImageDetails.from_dict(image) for image in detail]
        )
