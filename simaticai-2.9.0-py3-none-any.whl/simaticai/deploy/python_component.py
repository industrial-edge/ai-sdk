# SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
# SPDX-License-Identifier: MIT

import logging
import os
import shutil
import sys
import zipfile
import yaml
from pathlib import Path
import re

from simaticai.deploy.component import Component
from simaticai.packaging.python_dependencies import PythonDependencies
from simaticai.packaging.wheelhouse import create_wheelhouse
from simaticai.helpers import compare_versions
from simaticai.packaging.constants import (
    MANIFEST_FILE_NAME, DEPENDENCIES_FILE_NAME,
    REQUIREMENTS_TXT, PYTHON_PACKAGES_ZIP,  # component dependency configuration
    PYTHON_PACKAGES,  # additional constants
    SUPPORTED_TORCH_CUDA_DEPENDENCIES,
    MINIMUM_SUPPORTED_TENSORFLOW_AND_CUDA_VERSION
)
from simaticai.packaging.supported_types import validate_types


logging.basicConfig()
logging.getLogger().handlers = [logging.StreamHandler(sys.stdout)]
_logger = logging.getLogger(__name__)
_logger.setLevel(logging.INFO)

__all__ = ['PythonComponent', 'python_version_validator']

def python_version_validator(version: str):
    """
    Checks if Python version string is valid and describes supported version.

    Only version 3.11 and 3.12 is supported. A patch version is optional and accepted but logs a warning.

    Accepted syntaxes are:

        - {major}.{minor}
        - {major}.{minor}.{patch}

    Args:
        version (str): Python version string

    Raises:
        ValueError: if the provided version is not supported
    """

    error_message = "The defined python version is not supported. Currently supported Python versions are 3.11 and 3.12. Python version must be specified only with major and minor version, e.g. '3.11'."

    warning_message = """Required Python version was specified with patch version.
                Please note that the patch digit of the required Python version is often not taken into account by the Python ecosystem,
                so there is no guarantee it has the desired effect."""

    match str(version).split('.'):
        case ('3', '11' | '12'):
            return  # no patch version, so no warning
        case ('3', '11' | '12', _):
            _logger.warning(warning_message)
        case _:
            raise ValueError(error_message)

class PythonComponent(Component):
    """
    A pipeline component implemented using Python scripts and libraries.

    A `PythonComponent` wraps Python code resource files such as saved models into a structured folder, which can be added to a pipeline
    configuration package.

    For a comprehensive overview on how to wrap ML models into Python components, we recommend you refer to
    the AI SDK User Manual, especially the guideline for writing pipeline components. We also recommend you
    study the example Python components in the E2E Tutorials for the AI SDK.

    A new `PythonComponent` is empty.

    Args:
        name (str): Component name. (default: inference)
        desc (str): Component description (optional)
        version (str): Component version. (default: 0.0.1)
        python_version (str): Python version on the target AI Inference Server.
            At the moment of writing, the current version supports Python 3.11 and 3.12.
    """

    def __init__(self, name: str = "inference", version: str = "0.0.1", python_version: str = '3.12', desc: str = "", gpu_enabled: bool = False):
        """
        Creates a new, empty Python component.

        Args:
            name (str): Component name. (default: inference)
            desc (str): Component description (optional)
            version (str): Component version. (default: 0.0.1)
            python_version (str): Python version on the target AI Inference Server. At the moment of writing, AI Inference Server supports Python 3.11 and 3.12.
            gpu_enabled (bool): If True the component can use GPU specific Python dependencies. Default is False.
        """

        super().__init__(name=name, desc=desc)

        try:
            python_version_validator(python_version)
        except ValueError as error:
            raise AssertionError(error)

        self.python_version = str(python_version)
        self.version = version
        self.metrics = {}
        self.entrypoint: Path | None = None
        self.resources = {}
        self.python_dependencies = PythonDependencies(python_version)
        self._replicas = 1
        self.no_deps = False
        self.gpu_enabled = gpu_enabled
        if gpu_enabled:
            self._replicas = 1
            self.python_dependencies.disable_dependency_optimization()

    def __repr__(self) -> str:
        text = super().__repr__()

        if len(self.metrics) > 0:
            text += "\nMetrics:\n"
            for name, metric in self.metrics.items():
                text += f"< {name}{': ' + metric['desc'] if metric.get('desc') is not None else ''}\n"

        if len(self.resources):
            text += "\nResources:\n"
            for path, base in self.resources.items():
                text += f"  {base}/{path.name}\n".replace('./', '')

        if self.entrypoint is not None:
            text += f"Entrypoint: {self.entrypoint}\n"

        return text

    def set_entrypoint(self, entrypoint: str):
        """
        Sets the entrypoint module for the component.

        The entrypoint is the Python code which is responsible for receiving the input data and producing a structured response with the output for the AI Inference Server.
        The script should consume a JSON string and produce another. See the short example below.

        The file will be copied into the root directory of the component on the AI Inference Server, so every file reference should be aligned.

        The example code below shows a basic structure of the entrypoint Python code.
        ```python
        import json
        import sys
        from pathlib import Path

        # by adding the parent folder of your modules to system path makes them available for relative import
        sys.path.insert(0, str(Path('./src').resolve()))
        from my_module import processor  # then the processor module can be imported

        def run(data: str):
            input_data = json.loads(data)  # incoming JSON string is loaded as a dictionary

            result = processor.process_data(input_data)  # the process_data can be called to process the incoming data

            # the code below creates the formatted output for the AI Inference Server
            if result is None:
                answer = {"ready": False, "output": None}
            else:
                answer = {"ready": True, "output": json.dumps(result)}

            return answer
        ```

        Args:
            entrypoint (str): Name of the new entrypoint script to be copied

        """

        if not any(key.name for key, value in self.resources.items() if key.name == entrypoint and value == '.'):
            raise AssertionError("Entrypoint must be added as resource to the root directory before setting up as entrypoint.")

        self.entrypoint = Path(entrypoint)

    def add_resources(self, base_dir: os.PathLike, resources: os.PathLike | list):
        """
        Adds files to a component.

        To make your file resources available on the AI Inference Server you need to add them to the package resources.
        These resources can be Python or config files, serialized ML models or reference data.
        They are then available on path {component_root}/{resources} in the runtime environment.
        When saving the package they will be copied from {base_dir}/{resources} into the package.
        Files in '__pycache__' folders will be excluded.
        Until version 2.3.0 of AI SDK hidden files and folders (starting with '.') are also excluded.

        Args:
            base_dir (path-like): Root folder of your code from which the resources are referred
            resources (os.PathLike or List): A single path or list of relative paths to resource files

        """

        base_dir = Path(base_dir).resolve().absolute()
        if not base_dir.is_dir():
            raise AssertionError(f"Parameter 'base_dir' must be a directory and available in path {base_dir}.")
        resources = resources if type(resources) is list else [resources]

        for resource in resources:
            self._add_resource(base_dir, resource)

    def _add_resource(self, base_dir: Path, resource: os.PathLike):
        if Path(resource).is_absolute() or '..' in resource:
            raise AssertionError("The resource path must be relative and cannot contain '/../' elements.")

        resource_path = base_dir / resource

        if resource_path.is_file():
            self._add_resource_file(base_dir, resource_path)
            return

        if resource_path.is_dir():
            for glob_path in resource_path.rglob("*"):
                if glob_path.is_file():
                    self._add_resource_file(base_dir, glob_path)
            return

        raise AssertionError(f"Specified resource is not a file or directory: '{resource}'")

    def _add_resource_file(self, base_dir: Path, resource_path: Path):

        if resource_path.name in self._ignored_files:
            raise AssertionError(f"ERROR! The file name '{resource_path.name}' is reserved and cannot be used in component resources. Please rename the file '{resource_path}'.")

        for parent in resource_path.parents:
            if parent.name == '__pycache__':
                return

        if resource_path in self.resources.keys():
            _logger.warning(f"Resource '{resource_path}' is already added to target directory '{self.resources[resource_path]}'")
            return

        self.resources[resource_path] = f"{resource_path.parent.relative_to(base_dir)}"

    def add_dependencies(self, packages: list):
        """
        Adds required dependencies for the Python code.

        The list must contain the name of the Python packages or tuples in the form of (name, version) which are required to execute the component on AI Inference Server.
        The method will search for the packages for the target platform and collect their transitive dependencies as well.
        Packages that are distributed only in source format can be added too, but only if they are pure Python packages.

        Args:
            packages (list): Can be a list of strings (name) or a list of tuples (name, version) of the required packages for component execution
        """
        self.python_dependencies.add_dependencies(packages)
        if self.gpu_enabled:
            self._check_tensorflow_cuda_dependencies()

    def set_requirements(self, requirements_path: os.PathLike, no_deps: bool = False):
        """
        Reads the defined dependencies from the given `requirements.txt` file and creates a new dependency list. Previously added dependencies will be cleared.

        The file format must follow Python's requirements file format defined in PEP 508.
        It can contain URLs to additional repositories in the form of `--extra-index-url=my.repo.example.com`.

        Args:
            requirements_path (str): Path of the given `requirements.txt` file
            no_deps (bool): If set to True, dependencies will be downloaded/installed without dependencies. Default False.
        """
        _, extra_index, index_url = self.python_dependencies.set_requirements(requirements_path)
        if no_deps:
            self.no_deps = True
            _logger.warning("WARNING! Requiring packages without their transitive dependencies is only supported on AI Inference Server version >=2.6.0")
            _logger.warning("WARNING! Requiring packages without their transitive dependencies may lead to missing dependencies and runtime errors. Use with caution!")

        if self.gpu_enabled:
            self._check_pytorch_cuda_dependencies(extra_index, index_url, SUPPORTED_TORCH_CUDA_DEPENDENCIES)
            self._check_tensorflow_cuda_dependencies()

    @staticmethod
    def _check_pytorch_cuda_dependencies(extra_index: list[str], index_url: str | None, supported_torch_cuda_versions: list[str]):
        """Checks the index urls and extra index urls for validity for PyTorch CUDA dependencies.
        If the URL does contain 'torch' it is checked against the supported PyTorch CUDA versions.
        For example, if the supported torch cuda versions are ["12.x", "13.1"],
        accepted URLs would be "https://download.pytorch.org/whl/cu128" or "https://download.pytorch.org/whl/cu131".
        Throws error if a PyTorch related URL is not valid.
        """
        for url in [index_url] + extra_index:
            if url is None or "torch" not in url.lower():
                continue
            if not PythonComponent._is_valid_torch_cuda_index_url(url, supported_torch_cuda_versions):
                error_msg = f"ERROR! GPU enabled component has a PyTorch index url '{url}' which may not contain the required CUDA dependencies. " \
                            f"Supported CUDA versions for PyTorch on AI Inference Server 2.9.0+ are: {','.join(supported_torch_cuda_versions)}. " \
                            "Please make sure that the index url contains the required dependencies for GPU execution."
                _logger.error(error_msg)
                raise AssertionError(error_msg)

    def _check_tensorflow_cuda_dependencies(self):
        """Checks if the defined dependencies contain TensorFlow with CUDA support without a specific version,
        or with lower version than the minimum required version for AI Inference Server.
        If such a dependency is found, an error is raised.
        """
        error_msg = f"ERROR! GPU enabled component {self.name} has a TensorFlow[and-cuda] dependency but does not specify an exact version. " \
                    f"Please specify an exact version, for example, 'tensorflow[and-cuda]=={MINIMUM_SUPPORTED_TENSORFLOW_AND_CUDA_VERSION}'."

        for dep_name, dep_spec in self.python_dependencies.dependencies.items():
            # dep_spec is a Spec class object, see simaticai/helpers/pep508::Spec
            if not dep_name.lower().startswith("tensorflow"):
                continue
            if 'and-cuda' not in [e.lower() for e in dep_spec.extras]:
                continue
            if len(dep_spec.version) != 1:
                _logger.error(error_msg)
                raise AssertionError(error_msg)
            operator, version = dep_spec.version[0]
            if operator != '==' or not self._is_given_version_acceptable(version):
                _logger.error(error_msg)
                raise AssertionError(error_msg)

    @staticmethod
    def _is_given_version_acceptable(version_str_1: str, version_str_2: str = MINIMUM_SUPPORTED_TENSORFLOW_AND_CUDA_VERSION) -> bool:
        """Returns true if version v1 >= v2, for example, 1.3 >= 1.2.0.
        Only major and minor version numbers are compared, patch numbers and other suffixes are ignored
        """
        return 0 <= compare_versions(version_str_1, version_str_2, ignore_patch=True)

    @staticmethod
    def _is_valid_torch_cuda_index_url(url: str, supported_torch_cuda_versions: list[str]) -> bool:

        # helper function to convert a supported torch cuda version string (like "12.x" or "13.1") into a regex pattern
        def _from_version_to_regex(version_string: str):
            major_version, minor_version = version_string.split('.')
            if minor_version.lower() == 'x':
                # Handle cases like "12.x"
                return rf".+download.pytorch.org/whl/cu{major_version}."
            else:
                # Handle cases like "13.1"
                return rf".+download.pytorch.org/whl/cu{major_version}{minor_version}"

        # check if the url matches to any of the regexes generated from the supported torch cuda versions
        return any(re.search(_from_version_to_regex(version), url) for version in supported_torch_cuda_versions)

    def set_pyproject_toml(self, pyproject_path: os.PathLike):
        """
        Reads the defined dependencies from the given `pyproject.toml` file and adds it to the requirements list.

        Only the dependencies defined in the `[project]` section will be added to the component.

        Args:
            pyproject_path (str): Path of the given `pyproject.toml` file
        """
        self.python_dependencies.set_pyproject_toml(pyproject_path)

    def add_python_packages(self, path: str) -> None:
        """
        Adds Python package(s) to the `PythonPackages.zip` file of the component.

        The `path` parameter can refer to either a `whl`, a `zip` or a `tar.gz` file.
        Zip files can be either a source distribution package or a collection of Python packages. Only pure Python source distributions are allowed.
        The dependency list of the component will be extended with the files added here, so that they will also get installed on the AI Inference Server.
        The method uses the `tempfile.tempdir` folder, so make sure that the folder is writeable.

        The wheel files must fulfill the requirements of the targeted device environment
        (e.g., the Python version must match the supported Python version of the targeted AI Inference Server, and the platform should be one of the supported ones too).

        Args:
            path (str): Path of the distribution file

        Examples:
            `component.add_python_packages('../resources/my_package-0.0.1-py3-none-any.wheel')`
                adds the wheel file to `PythonPackages.zip` and adds dictionary item `component.dependencies['my_package'] = '0.0.1'`

            `component.add_python_packages('../resources/inference-wheels.zip')`
                adds all the wheel files in the zip to `PythonPackages.zip` and `component.dependencies`
        """
        self.python_dependencies.add_python_packages(path)

    def set_parallel_steps(self, replicas):
        """
        Sets the number of parallel executors.

        This method configures how many instances of the component can be
        executed at the same time.
        The component must be suitable for parallel execution. Components that use the GPU
        can not be executed in parallel, so if GPU is enabled for the component,
        the number of replicas will be set to 1 and a warning will be logged.

        The inputs arriving to the component will be processed by different instances in parallel,
        and these instances do not share their state (e.g. variables). Every
        instance is initialized separately and receives only a fraction of the inputs.
        AI Inference Server supports at most 8 parallel instances.```

        Args:
            replicas (int): Number of parallel executors. Default is 1.

        Raises:
            ValueError: if the given argument is not a positive integer.
        """
        if (not isinstance(replicas, int)) or replicas < 1:
            raise ValueError("Replica count must be a positive integer.")
        if 8 < replicas:
            _logger.warning("The current maximum of parallel executors is 8.")
        if self.gpu_enabled and replicas > 1:
            _logger.warning("Parallel execution with GPU enabled is not supported. Reverting to single executor.")
            self._replicas = 1
        else:
            self._replicas = replicas

    def add_metric(self, name: str, desc: str | None = None):
        """
        Adds a metric that will be automatically used as a pipeline output.

        Args:
            name (str): Name of the metric.
            desc (str): Description of the metric. (optional)
        """
        if "_" not in name:
            raise AssertionError("The metric name must contain at least one underscore")
        if self.metrics is None:
            self.metrics = {}
        if name in self.metrics:
            raise AssertionError(f"Metric '{name}' already exists")
        self.metrics[name] = {}
        if desc is not None:
            self.metrics[name]['desc'] = desc

    def delete_metric(self, name: str):
        """
        Remove a previously added metric.

        Args:
            name (str): Name of the metric to be deleted.
        """
        if name not in self.metrics:
            raise AssertionError(f"Component '{self.name}' has no metric '{name}'")
        self.metrics.pop(name)

    def _to_dict(self):
        runtime = {
            'type': 'python',
            'version': self.python_version,
        }
        if self.no_deps:
            runtime['installTransitiveDependencies'] = False

        component_dict = {
            **super()._to_dict(),
            'version': self.version,
            'entrypoint': f"./{self.entrypoint.name}",
            'hwType': 'GPU' if self.gpu_enabled else 'CPU',
            'runtime': runtime,
            'replicas': self._replicas
        }

        component_dict["outputType"] += [{
            'name': name,
            'type': 'String',
            'metric': True,
        } for name in self.metrics.keys()]

        return component_dict

    def enable_dependency_optimization(self):
        """
        Allows changing repository URLs to optimize the package size

        Allows the replacement of the `--index-url` argument during `pip download` to download
        CPU runtime optimized dependencies only. Enabling this optimization, the present
        `--index-url` will be prepended to the `--extra-index-url` list, and the Pytorch CPU only repository
        will be set as the `--index-url`.
        A warning message will be printed if the repository URL modification was necessary.
        Some dependencies have both CPU and GPU runtime
        versions, pytorch for example. When a `PythonComponent` does not need the GPU runtime,
        packaging the additional GPU runtime dependencies just enlarges the package size.
        If you want to run your model on GPU, convert it to an `ONNX` model and use it within a
        `GPURuntimeComponent` or create the PythonComponent with the `gpu_enabled` parameter set to True.
        In this case the dependency optimization will be automatically disabled, and a warning message
        will be printed.
        """
        if self.gpu_enabled:
            _logger.warning("GPU enabled components are not optimized for package size. Enabling dependency optimization has no effect.")
            return
        self.python_dependencies.enable_dependency_optimization()

    def disable_dependency_optimization(self):
        """
        Disables any modification to repository URLs

        Disables the replacement of the `--index-url` argument during `pip download`.
        This way all `--index-url` or `--extra-index-url` arguments will be preserved if they
        were present in the requirements.txt file.
        Some dependencies have both CPU and GPU runtime
        versions, pytorch for example, but a `PythonComponent` can only run on CPU, so
        packaging the additional GPU runtime dependencies just enlarges the package size.
        A warning message will be printed about the package size if this optimization is disabled and
        the dependency list contains GPU optimized dependencies.
        Disabling this optimization will not allow the component to run on GPU.
        If you want to run your model on GPU, convert it to an `ONNX` model and use it within a
        `GPURuntimeComponent`.
        """
        self.python_dependencies.disable_dependency_optimization()

    def validate(self):
        """
        Validates that the component is ready to be serialized and packaged as part of a pipeline.
        """
        try:
            python_version_validator(self.python_version)
        except ValueError as error:
            raise AssertionError(error)

        if self.entrypoint is None:
            raise AssertionError("Entrypoint must be defined")
        if not any(key.name for key, value in self.resources.items() if key.name == self.entrypoint.name and value == '.'):
            raise AssertionError("Entrypoint must be added as resource to the root directory before setting up as entrypoint.")

        # Validate all input and output types
        _logger.info(f"Validating component '{self.name}' with {len(self.inputs)} inputs and {len(self.outputs)} outputs.")
        inputs_and_outputs = {**self.inputs, **self.outputs}
        for name, input_data in inputs_and_outputs.items():
            logLevel, message = validate_types(input_data['type'], name=name)
            match logLevel, message:
                case logging.WARNING, str():
                    _logger.log(logLevel, message)
                case logging.ERROR, str():
                    raise AssertionError(message)

        if len(self.python_dependencies.dependencies) < 1:
            _logger.warning(f"WARNING! There are no dependencies defined for component '{self.name}'. Please make sure that all necessary dependencies have been added.")

        if self.no_deps:
            _logger.warning(f"WARNING! Component `{self.name}` is requested to be installed without transitive dependencies. "
                            "This may lead to runtime errors if the dependencies are not handled manually.")

        self.python_dependencies.validate()

        _logger.info(f"Component '{self.name}' is valid and ready to use.")

    def save(self, destination: Path | str, validate: bool = True):
        """
        Saves the component to a folder structure, so it can be used as part of a pipeline configuration package.
        Validation can be skipped by setting parameter `validate` to False.
        This is useful when the component is already validated and only intended to be saved.

        The component folder contains the following:

        - `requirements.txt` with a list of Python dependencies
        - Entry point script defined by the `entrypoint` attribute of the component
        - Extra files as added to the specified folders
        - `PythonPackages.zip` with the wheel binaries for the environment to be installed

        Args:
            destination (path-like): Target directory to which the component will be saved.
            validate (bool): With value True, triggers component validation. Defaults to True.
        """
        if validate:
            self.validate()

        folder_path = Path(destination) / self.name
        folder_path.mkdir(parents=True, exist_ok=True)

        for file_path in self.resources:
            dir_path = folder_path / self.resources[file_path]
            os.makedirs(dir_path, exist_ok=True)
            shutil.copy(file_path, dir_path / file_path.name)

        self.python_dependencies.save(folder_path)

    def _enforce_single_thread_for_transitive_gpu_dependencies(self, dependency_set: set):
        """
        Check for GPU dependencies and set parallel steps (replicas) to 1 if necessary.
        If any of the dependencies in the set starts with "nvidia-cuda", it is considered
        a GPU dependency. If GPU dependencies are found and the current number of replicas
        is greater than 1, a warning is logged and the number of replicas is set to 1.

        Args:
            dependency_set (set): Set of dependencies to check for GPU requirements.
        """
        dependency_set_names = [d.lower() for d, _ in dependency_set]
        has_gpu_dependency = next((True for dep in dependency_set_names if dep.startswith("nvidia-cuda")), False)
        if has_gpu_dependency and self._replicas > 1:
            _logger.warning(f"Component '{self.name}' cannot have multiple parallel steps with GPU dependency, because of the GPU resource limitation. Setting parallel steps to 1.")
            self._replicas = 1

    def export(self, destination: Path | str, package_type: str = "full", previous_package: dict | None = None, report_writer = None) -> tuple[Path, dict]:
        """
        Exports the component as a packaged artifact ready for deployment.

        Validates the component and creates a deployable package by:
        - Creating a component directory structure
        - Copying resources to the appropriate locations
        - Extracting and organizing Python packages
        - Resolving dependencies using wheelhouse
        - Creating dependency and file lists with checksums
        - Generating a zipped component archive

        The exported component contains:
        - Component metadata and configuration
        - All resource files organized by type
        - requirements.txt with filtered dependency specifications
        - PythonPackages.zip with resolved wheel dependencies
        - Dependency list with file hashes for integrity verification
        - File list with sizes and hashes for all component files

        Args:
            destination (Path | str): Target directory where the component package will be created.
                The final package will be located at {destination}/components/{name}_{version}.zip

        Returns:
            tuple[Path, dict, list, set]: A tuple containing the path to the created component zip file,
            the file manifest with checksums, the dependency list, and the dependency set.

        Raises:
            AssertionError: If component validation fails
        """
        self.validate()

        destination = Path(destination) / "components"
        component_dir = destination / self.name
        python_packages_folder = component_dir / 'packages'
        shutil.rmtree(component_dir, ignore_errors=True)
        python_packages_folder.mkdir(parents=True, exist_ok=True)

        packages_file = component_dir / PYTHON_PACKAGES_ZIP
        requirements_file_path = component_dir / REQUIREMENTS_TXT
        requirements_file_path.touch(exist_ok=True)

        for file_path in self.resources.keys():
            dir_path = component_dir / self.resources[file_path]
            os.makedirs(dir_path, exist_ok=True)
            shutil.copy(file_path, dir_path / file_path.name)

        self.python_dependencies.save(component_dir)

        if packages_file.is_file():
            with zipfile.ZipFile(packages_file) as zip_file:
                zip_file.extractall(python_packages_folder)
            packages_file.unlink()

        previous_manifest = None
        if previous_package is not None:
            previous_manifest = previous_package["contents"].get("components", {}).get(self.name, None)
        try:
            dependency_set = set()
            if previous_manifest is None or package_type not in ["auto", "delta"]:
                dependency_set = create_wheelhouse(requirements_file_path, self.python_version, python_packages_folder, self.no_deps)
                self._enforce_single_thread_for_transitive_gpu_dependencies(dependency_set)
                # This filtering needs to happen here, not in PythonDependencies,
                # because create_wheelhouse() still needs the original requirements.txt
                # with the extra index urls.
                with open(requirements_file_path, "r") as f:
                    lines = f.readlines()
                filtered_lines = list(filter(lambda x: not (x.startswith("# Extra") or x.startswith("--extra-index-url") or x.startswith("# Index") or x.startswith("--index-url")), lines))
                with open(requirements_file_path, "w") as f:
                    f.writelines(filtered_lines)
                dependency_list = {
                    "name": self.name,
                    "python_version": self.python_version,
                    "gpu": self.gpu_enabled,
                    "dependencies": self._collect_file_sizes_and_hashes(python_packages_folder)
                }
            else:
                dependency_list = {
                    "name": self.name,
                    "python_version": self.python_version,
                    "gpu": self.gpu_enabled,
                    "dependencies": previous_manifest["dependencies"]
                }

            if "fine-grained-delta" == package_type:
                self._remove_unchanged_files_from_delta(previous_manifest, "dependencies", dependency_list["dependencies"], python_packages_folder)

            with open(component_dir / DEPENDENCIES_FILE_NAME, 'w') as list_file:
                yaml.dump(dependency_list, list_file, sort_keys=False)

            if package_type not in ["auto", "delta"]:
                if any(Path(python_packages_folder).iterdir()) and (package_type not in ["auto", "delta"]):
                    shutil.make_archive(
                        base_name=str(component_dir / PYTHON_PACKAGES),
                        format='zip',
                        root_dir=python_packages_folder,
                        verbose=True,
                        logger=_logger)
            shutil.rmtree(python_packages_folder)

            component_files = self._collect_file_sizes_and_hashes(component_dir)
            if "fine-grained-delta" == package_type:
                self._remove_unchanged_files_from_delta(previous_manifest, "files", component_files, component_dir)

            if package_type in ["auto", "delta"]:
                packages_zip = [f for f in previous_manifest["files"] if f["path"].endswith(PYTHON_PACKAGES_ZIP)]
                if 0 < len(packages_zip):
                    component_files.append(packages_zip[0])

            with open(component_dir / MANIFEST_FILE_NAME, 'w') as list_file:
                yaml.dump(component_files, list_file, sort_keys=False)

            zipped_component_path = destination / f"{self.name}_{self.version}"
            zipped_component_path = self._create_component_zip(component_dir, zipped_component_path)

            dependencies = self.python_dependencies.dependencies
            manifest = {
                'sizeInBytes': zipped_component_path.stat().st_size,
                'files': component_files,
                'dependencies': dependency_list["dependencies"],
                'requirements': [ str(rq) for _,rq in dependencies.items() ]
            }
            if report_writer is not None:
                report_writer.add_direct_dependencies(self.name, dependencies)
                report_writer.add_full_dependency_set(self.name, dependency_set)

            return zipped_component_path, manifest

        finally:
            shutil.rmtree(component_dir, ignore_errors=True)
