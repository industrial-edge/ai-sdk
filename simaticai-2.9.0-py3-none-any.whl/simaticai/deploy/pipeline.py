# SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
# SPDX-License-Identifier: MIT

import json
import jsonschema
import jsonschema.exceptions
import logging
import math
import os
import platform
import re
import shutil
import sys
import uuid
import yaml
import zipfile
from importlib import resources as module_resources
from importlib import metadata as importlib_metadata
from pathlib import Path, PurePath
from typing import Optional, Tuple, Union, List
from functools import cmp_to_key

import simaticai.deploy.pipeline_page as p_page
from simaticai.deploy.component import Component
from simaticai.deploy.python_component import PythonComponent, python_version_validator
from simaticai.payloads import PipelineVariable, PipelineParameter, SecretPipelineParameter
from simaticai.deploy.pipeline_data import PipelineData
from simaticai.telemetry.consent import (
    is_telemetry_allowed, read_telemetry_consent_file, get_consent_source,
    CONSENT_KEY, CONSENT_KEY_TS, CONSENT_KEY_SDK, CONSENT_KEY_METHOD
)

from simaticai.helpers import tempfiles, yaml_helper, calc_sha, compare_versions, timestamp_aiis_compatible, increment_version
from simaticai.packaging.wheelhouse import create_wheelhouse
from simaticai.helpers.reporter import PipelineReportWriter, ReportWriterHandler
from simaticai.packaging.python_dependencies import _logger as _python_dependencies_logger
from simaticai.packaging.wheelhouse import _logger as _wheelhouse_logger
from simaticai.deploy.component import _logger as _component_logger
from simaticai.deploy.python_component import _logger as _python_component_logger
from simaticai.deploy.gpuruntime_component import _logger as _gpuruntime_component_logger

from simaticai.packaging.constants import (
    PIPELINE_CONFIG, PIPELINE_CONTENT, RUNTIME_CONFIG, DATALINK_METADATA,  # pipeline configuration files
    TELEMETRY_YAML, README_HTML,  # additional pipeline information files
    REQUIREMENTS_TXT, PYTHON_PACKAGES_ZIP,  # component dependency configuration
    PYTHON_PACKAGES, MSG_NOT_FOUND, PACKAGE_SIZE_LIMIT, PACKAGE_SIZE_HARD_LIMIT  # additional constants
)

logging.basicConfig()
logging.getLogger().handlers = [logging.StreamHandler(sys.stdout)]
_logger = logging.getLogger(__name__)
_logger.setLevel(logging.INFO)

__all__ = [
    'Pipeline',
    'convert_package',
    '_validate_with_schema',
    '_package_component',
    '_package_component_dependencies',
    '_generate_runtime_config'
]

rib_cycle_time_warning_message = "RIB cycle time is recommended to be between 1 and 1000 milliseconds."
rib_cycle_time_error_message = "RIB cycle time must be a positive number in milliseconds (integer or float) no less than 0.001."

class Pipeline(PipelineData):
    """
    `Pipeline` represents a pipeline configuration package with `Components` and wires to provide a data flow on the AI Inference Server.
    The `Components` have inputs and outputs to transfer data to each other and the wires describe this data flow between them.
    The package also contains configuration files required to deploy a pipeline on an Industrial Edge device.

    A newly initialized `Pipeline` does not contain any `Component` or wire, only its name and version will be set.
    The name and version together will define the name of the zip file when the package is saved.

    Args:
        name (str): Name of the package
        version (str): Version of the package
    """
    _wire_hash_string = "{}.{} -> {}.{}"

    def __init__(self, name: str, version: Optional[str] = None, desc: str = ""):
        """
        A newly initialized `Pipeline` will contain no `Component` or wire, just its name and version will be set.
        The name and version will define together the name of the zip file when the package is saved.

        Args:
            name (str): Name of the package
            desc (str): Package description (optional)
            version (str): Version of the package
        """

        super().__init__(name, version, desc)

        self.report_writer = PipelineReportWriter()
        report_writer_handler = ReportWriterHandler(self.report_writer)
        _logger.addHandler(report_writer_handler)
        _python_dependencies_logger.addHandler(report_writer_handler)
        _wheelhouse_logger.addHandler(report_writer_handler)
        _component_logger.addHandler(report_writer_handler)
        _python_component_logger.addHandler(report_writer_handler)
        _gpuruntime_component_logger.addHandler(report_writer_handler)

    def _set_log_level(self, log_level: int):
        self.log_level = log_level
        _logger.setLevel(self.log_level)

    @staticmethod
    def from_components(components: list, name: str, version: Optional[str] = None, desc: str = "") -> "Pipeline":
        """
        Creates a pipeline configuration from the given components.
        The components are linked in a linear sequence with inputs and outputs auto-wired based on the name of the inputs and outputs of the components.
        The inputs of the first component will be wired as the pipeline inputs and the outputs of the last component will be wired as the pipeline outputs.
        The components must have unique names. Two or more versions of the same component can not be packaged simultaneously without renaming them.

        Args:
            components (list): List of PythonComponents
            name (str): Name of the pipeline
            version (str): Version information of the pipeline. (Optional)
        Returns:
            Pipeline: Pipeline object with the auto-wired components
        """
        pipeline = Pipeline(name, version, desc=desc)

        first_component = components[0]
        pipeline.add_component(first_component)
        pipeline.inputs = [PipelineVariable(first_component.name, component_input) for component_input in first_component.inputs]
        pipeline.outputs = [PipelineVariable(first_component.name, output) for output in first_component.outputs]

        for component in components[1:]:
            pipeline.add_component(component)
            for t_output in pipeline.outputs:
                try:
                    pipeline.add_wiring(t_output.componentName, t_output.variableName, component.name, t_output.variableName)
                except Exception as e:
                    _logger.warning(f"Output variable {t_output.componentName}.{t_output.variableName} couldn't be auto-wired.\nCause: {e}")

            unwired_variables = [f'{component.name}.{x}' for x in component.inputs if not any(s.endswith(f'{component.name}.{x}') for s in pipeline.wiring)]
            if len(unwired_variables) > 0:
                for variable in unwired_variables:
                    _logger.warning(f"Input variable {variable} couldn't be auto-wired.\n")
            pipeline.outputs = [PipelineVariable(component.name, output) for output in component.outputs]

        # ImageSet is not allowed in pipeline outputs
        for i, o in enumerate(pipeline.outputs):
            if pipeline.components[o.componentName].outputs[o.variableName]["type"].lower() == 'imageset':
                _logger.warning(f"Output variable {o.componentName}.{o.variableName} of type 'ImageSet' can not be added as pipeline output.")
                pipeline.outputs.pop(i)

        return pipeline

    def __repr__(self) -> str:
        """
        Textual representation of the configured package.
        The method shows the `Components` with their inputs, outputs and parameters as well as the wiring between these `Components`.

        Returns:
            [str]: Textual representation of the package
        """
        version = self.save_version if self.save_version is not None else self.init_version

        text = f"[{self.__class__.__name__}] {self.name} ({version})\n"
        if self.desc != "":
            text += f"{self.desc}\n"

        if len(self.parameters) > 0:
            text += "\nPipeline Parameters:\n"
            for parameter in self.parameters:
                text += f"- {parameter.name} ({parameter.dtype}, default: '{parameter.defaultValue}'){(': ' + parameter.description) if parameter.description is not None else ''}\n"

        if len(self.inputs) > 0:
            text += "\nPipeline Inputs:\n"
            for p_input in self.inputs:
                c_input = self.components[p_input.componentName].inputs[p_input.variableName]
                text += f"> {p_input.variableName} ({c_input['type']}){': ' + c_input['desc'] if c_input.get('desc') is not None else ''}\n"

        if len(self.outputs) > 0:
            text += "\nPipeline Outputs:\n"
            for p_output in self.outputs:
                c_output = self.components[p_output.componentName].outputs[p_output.variableName]
                text += f"< {p_output.variableName} ({c_output['type']}){': ' + c_output['desc'] if c_output.get('desc') is not None else ''}\n"

        metrics = [(name, metric, component_name) for component_name, component in self.components.items() if isinstance(component, PythonComponent) for name, metric in component.metrics.items()]
        if len(metrics) > 0:
            text += "\nMetrics:\n"
            for name, metric, _ in metrics:
                text += f"< {name}{': ' + metric['desc'] if metric.get('desc') is not None else ''}\n"

        if len(self.wiring) > 0:
            text += "\nI/O Wiring:\n"
            for p_input in self.inputs:
                text += f"  {p_input.variableName} -> {p_input.componentName}.{p_input.variableName}\n"
            for wire_hash in self.wiring:
                text += f"  {wire_hash}\n"
            for p_output in self.outputs:
                text += f"  {p_output.componentName}.{p_output.variableName} -> {p_output.variableName}\n"
            for name, metric, component_name in metrics:
                text += f"  {component_name}.{name} -> {name}\n"

        if self.periodicity is not None:
            text += "\nTimeshifting:\n"
            text += f"  Periodicity: {self.periodicity} ms\n"
            if len(self.timeshift_reference) > 0:
                text += "  References:\n"
                for ref in self.timeshift_reference:
                    text += f"  - {ref}\n"

        if self.rib_cycle_time is not None:
            text += f"\nRIB Cycle Time: {self.rib_cycle_time / 1000:.3f} ms\n"

        for component in self.components.values():
            text += "\n" + component.__repr__()

        return text

    def add_input(self, component, variable):
        """
        Defines an input variable on the given component as a pipeline input.

        Args:
            component (str): Name of the component
            variable (str): Name of the input variable
        """
        try:
            _ = self.components[component].inputs[variable]
        except KeyError:
            raise AssertionError("The component with input variable must exist in the pipeline.")

        if self.inputs is None:
            self.inputs = []

        if self._get_io_index(self.inputs, variable) is not None:
            raise AssertionError("The pipeline input already exists.")

        self.inputs.append(PipelineVariable(componentName=component, variableName=variable))

    def delete_input(self, component: str, variable: str):
        """
        Deletes a pipeline input.

        Args:
            component (str): Name of the component
            variable (str): Name of the input variable
        """

        if (idx := self._get_io_index(self.inputs, variable)) is None:
            raise AssertionError("The pipeline input does not exist.")

        self.inputs.pop(idx)

    def add_output(self, component, variable):
        """
        Defines an output variable on the given component as a pipeline output.

        Args:
            component (str): Name of the component
            variable (str): Name of the output variable

        """
        try:
            output = self.components[component].outputs[variable]
        except KeyError:
            raise AssertionError("The component with output variable must exist in the pipeline.")

        if self.outputs is None:
            self.outputs = []

        if self._get_io_index(self.outputs, variable) is not None:
            raise AssertionError("The pipeline output already exists.")

        if output["type"].lower() == 'imageset':
            _logger.warning("Output variables of type 'ImageSet' can not be added as pipeline outputs.")

        self.outputs.append(PipelineVariable(componentName=component, variableName=variable))

    def delete_output(self, component: str, variable: str):
        """
        Deletes a pipeline output.

        Args:
            component (str): Name of the component
            variable (str): Name of the output variable

        """

        if (idx := self._get_io_index(self.outputs, variable)) is None:
            raise AssertionError("The pipeline output does not exist.")

        self.outputs.pop(idx)

    def add_component(self, component: Component):
        """
        Adds a `Component` to the pipeline configuration without any connection.
        The component must have a unique name. Two or more versions of the same component can not be added to the same pipeline with the same component name.

        Args:
            component (Component): `Component` to be added
        """

        if component.name in self.components:
            raise AssertionError(f"Component with name {component.name} already exists. Please rename the component.")
        self.components[component.name] = component

    def add_wiring(self, from_component: str, from_output: str, to_component: str, to_input: str):
        """
        Creates a one-to-one connection between the input and output of two components.
        The method checks if the connection is allowed with the following requirements:

        - The components exist with the given inputs/outputs
        - The given inputs and outputs are not connected to any wire
        - The types of the connected input and output are compatible

        Args:
            from_component (str): Name of the component which provides data to the `to_component`
            from_output (str): Name of the output variable of the `from_component`
            to_component (str): Name of the component which consumes data from the `from_component`
            to_input (str): Name of the input variable of the `to_component`
        """
        if from_component not in self.components:
            raise AssertionError(f"No component named '{from_component}'")
        if to_component not in self.components:
            raise AssertionError(f"No component named '{to_component}'")
        if from_output not in self.components[from_component].outputs:
            raise AssertionError(f"Component '{from_component}' has no output named '{from_output}'")
        if to_input not in self.components[to_component].inputs:
            raise AssertionError(f"Component '{to_component}' has no input named '{to_input}'")
        if self.get_wire_for_input(to_component, to_input) is not None:
            raise AssertionError(f"Input '{to_input}' of component '{to_component}' is already wired")

        _output_type = self.components[from_component].outputs[from_output]["type"]
        _input_type = self.components[to_component].inputs[to_input]["type"]
        if _output_type != _input_type:
            raise AssertionError("Output and input types do not match")

        wire_hash = self._wire_hash_string.format(from_component, from_output, to_component, to_input)
        self.wiring[wire_hash] = {
            "fromComponent": from_component,
            "fromOutput": from_output,
            "toComponent": to_component,
            "toInput": to_input,
        }

    def get_wire_for_output(self, component_name: str, output_name: str) -> Optional[dict]:
        """
        Searches for the wire which connects a component with `component_name` as data provider through its output with name output_name.

        Args:
            component_name (str): Name of the data provider component.
            output_name (str): Name of the output variable of `component_name`.

        Returns:
            Optional[dict]: Wire which contains the data provider and receiver with their names and the names of their variables.
        """
        wires = [x for x in self.wiring.values() if x["fromComponent"] == component_name and x["fromOutput"] == output_name]
        return wires[0] if wires else None

    def get_wire_for_input(self, component_name: str, input_name: str) -> Optional[dict]:
        """
        Searches for the wire which connects a component with `component_name` as data consumer through its input with name `input_name`.

        Args:
            component_name (str): Name of the data consumer component.
            input_name (str): Name of the input variable of `component_name`.

        Returns:
            Optional[dict]: Wire which contains the data provider and receiver with their names and the names of their variables.
        """
        wires = [x for x in self.wiring.values() if x["toComponent"] == component_name and x["toInput"] == input_name]
        return wires[0] if wires else None

    def delete_input_wire(self, component: str, variable: str, with_input: bool = True) -> None:
        """
        Deletes an existing connection between two components.
        The connection must be given with the name of the consumer component and its input variable.
        If an inter signal alignment reference variable is affected it cannot be deleted.
        By default, the input variable will be also deleted.

        Args:
            component (str): Name of the component which has the input given the name variable
            variable (str): Name of the input variable on the component which connected by the wire
            with_input (bool, optional): If set, the input variable will be also deleted from the component. Defaults to True.

        Raises:
            AssertionError: When the variable acts as inter signal alignment reference, it cannot be deleted, and an `AssertionError` will be raised.
        """
        wire = self.get_wire_for_input(component, variable)
        if wire is None:
            raise AssertionError(f"There is no wiring for input '{variable}' of component '{component}'")
        if variable in self.timeshift_reference:
            raise AssertionError("Inter signal alignment reference variables can not be deleted.")
        wire_hash = self._wire_hash_string.format(wire['fromComponent'], wire['fromOutput'], wire['toComponent'], wire['toInput'])
        self.wiring.pop(wire_hash)

        if with_input:
            self.components[component].delete_input(variable)

    def add_dependencies(self, packages: list) -> None:
        """
        @Deprecated, reason: components can have different Python versions and/or platform, therefore it's better to specify dependencies on a case-by-case basis.
        Collects the given Python packages with their versions from the executing Python environment and add them to all components of type `PythonComponent`.
        This step is necessary in order to execute the pipeline configuration on the Edge side.
        The method can be called multiple times but each time the previously-collected dependencies are cleared.
        The reason for this is to ensure a consistent dependency list for the `requirements.txt` file when the package is saved.

        Args:
            packages (list): List of the necessary python packages to execute the script defined by self.entrypoint
        """
        python_components = [self.components[name] for name in self.components if type(self.components[name]) is PythonComponent]
        for component in python_components:
            component.add_dependencies(packages)

    def set_timeshifting_periodicity(self, periodicity: int) -> None:
        """
        Enables inter-signal alignment with the given sampling period.

        With inter-signal alignment enabled, the AI Inference Server collects data for different input variables before it triggers the model.
        By default, `startingPoint` property is set to `First timestamp`, which means that inter-signal alignment is started at the
        first incoming value for any input variable.

        This property can be changed to `Signal reference` by adding inter-signal alignment reference variables
        via the `add_timeshifting_reference(..)` method. In this case, inter-signal alignment is started when the first value arrives
        for the defined input variables.

        Args:
            periodicity (int): Periodicity time in milliseconds for the AI Inference Server to perform inter-signal alignment. Valid range is [10, 2^31).
        """

        periodicity = int(periodicity)
        if periodicity not in range(10, int(math.pow(2, 31))):
            raise AssertionError("Inter signal alignment periodicity must be an integer and in range [10, 2^31)")

        self.periodicity = periodicity
        _logger.info(f"Inter signal alignment periodicity has been set to {self.periodicity}.")

    def add_timeshifting_reference(self, reference: str) -> None:
        """
        Enables signal alignment mode `Signal reference` by declaring input variables as reference variables.

        Args:
            reference (str): Variable name to be added to `self.timeshift_reference` list.
        """
        if reference not in [i.variableName for i in self.inputs]:
            raise AssertionError(f"There is no input variable defined with name '{reference}'")
        if reference in self.timeshift_reference:
            _logger.warning(f"Reference variable with name '{reference}' has been already added.")
            return
        self.timeshift_reference.append(reference)

    def remove_timeshifting_reference(self, reference: str) -> None:
        """
        Removes previously-defined inter-signal alignment reference variables.
        If no reference variables remain, the `startingPoint` will be `First timestamp`.

        Args:
            reference (str): Variable name to be removed from `self.timeshift_reference` list.
        """
        if reference not in self.timeshift_reference:
            raise AssertionError(f"Reference variable with name {'reference'} does not exist.")
        self.timeshift_reference.remove(reference)

    def set_rib_cycle_time(self, cycle_time_msec: int | float):
        """
        Sets the cycle time for the pipeline. Logs a warning message if the value is not between 1 and 1000 milliseconds, as it is the recommended range for RIB cycle time.
        Raises value error if the provided cycle time is less than 0.001 ms.

        Args:
            cycle_time_msec (int | float): Cycle time in milliseconds. Must be a positive integer or float.
        """

        self.rib_cycle_time = self._get_validated_rib_cycle_time(1000 * cycle_time_msec)

    def get_pipeline_config(self) -> dict:
        """
        Saves the information on the composed pipeline configuration package into a YAML file.

        This YAML file describes the components and the data flow between them for the AI Inference Server.
        The file is created in the `destination` folder with name `pipeline_config.yml`
        """
        version = self.save_version if self.save_version is not None else self.init_version

        metric_fields = [(component_name, field) for component_name, component in self.components.items() if isinstance(component, PythonComponent) for field in component.metrics.keys()]

        pipeline_inputs = [
            i.__dict__(self.components[i.componentName].inputs)
            for i in self.inputs
        ]

        pipeline_outputs = [
            {**o.__dict__(self.components[o.componentName].outputs), 'metric': False}
            for o in self.outputs
        ]

        pipeline_outputs += [{
            'name': field,
            'type': 'String',
            'metric': True,
            'topic': f"/siemens/edge/aiinference/{self.name}/{version}/metrics/{component_name}/{field}",
        } for component_name, field in metric_fields]

        pipeline_dag = [{
            'source': f'Databus.{i.variableName}',
            'target': f'{i.componentName}.{i.variableName}',
        } for i in self.inputs]

        pipeline_dag += [{
            'source': f"{wire['fromComponent']}.{wire['fromOutput']}",
            'target': f"{wire['toComponent']}.{wire['toInput']}",
        } for wire in self.wiring.values()]

        pipeline_dag += [{
            'source': f'{o.componentName}.{o.variableName}',
            'target': f'Databus.{o.variableName}',
        } for o in self.outputs]

        pipeline_dag += [{
            'source': f'{component_name}.{field}',
            'target': f'Databus.{field}',
        } for component_name, field in metric_fields]

        # Add delta package information to description if applicable
        description = self.desc if self.desc else 'Created by AI SDK'
        if self.package_type == "delta" and self.origin_version:
            base_package_name = f"{self.name.replace(' ', '-')}-edge_{self.origin_version}.zip"
            description += f" (Delta package generated based on {base_package_name})"
        
        config_yml_content = {
            'fileFormatVersion': '1.3.0',
            'dataFlowPipelineInfo': {
                'author': self.author,
                'createdOn': timestamp_aiis_compatible(),
                'dataFlowPipelineVersion': f"{version}",
                'description': description,
                'projectName': self.name,
                'packageId': str(self.package_id)
            },
            'dataFlowPipeline': {
                'components': [component._to_dict() for component in self.components.values()],
                'pipelineDag': pipeline_dag,
                'pipelineInputs': pipeline_inputs,
                'pipelineOutputs': pipeline_outputs,
            },
            'packageType': self.package_type,
        }

        if self.package_type == "delta":
            config_yml_content["originVersion"] = f"{self.origin_version}"

        if len(self.parameters) > 0:
            config_yml_content["dataFlowPipeline"]["pipelineParameters"] = [
                param.__param_dict__()
                for param in self.parameters
            ]
        if self.rib_cycle_time is not None:
            config_yml_content["dataFlowPipeline"]["ribCycleTime"] = self.rib_cycle_time

        return config_yml_content

    def save_pipeline_config(self, destination: Path | str) -> dict:
        """
        Saves the information about the composed pipeline configuration package into a YAML file.

        This YAML file describes the components and the data flow between them for AI Inference Server.
        The file will be created in the `destination` folder with name `pipeline_config.yml`

        Args:
            destination (path-like): Path of the `destination` directory.
        """
        pipeline_config = self.get_pipeline_config()
        with open(Path(destination) / PIPELINE_CONFIG, "w", encoding="utf8") as f:
            yaml.dump(pipeline_config, f, sort_keys=False)
        return pipeline_config

    def get_datalink_metadata(self) -> dict:
        """
        The method generates metadata information based on available information.

        Returns:
            dict: Dictionary with the necessary information for the AI Inference Server.
        """

        timeshifting = {
            "id": None,
            "enabled": False,
            "periodicity": self.periodicity,
            "startingPoint": None,
        }

        if self.periodicity is not None:
            timeshifting["enabled"] = True
            timeshifting["startingPoint"] = 'First timestamp'

        if len(self.timeshift_reference) > 0:
            timeshifting["startingPoint"] = 'Signal reference'

        exported_metadata = {
            "fileFormatVersion": "1.0.0",
            "id": None,
            "version": None,
            "createdOn": timestamp_aiis_compatible(),
            "updatedOn": timestamp_aiis_compatible(),
            "timeShifting": timeshifting,
            "inputs": [
                {
                    'name': input.variableName,
                    'mapping': None,
                    'timeShiftingReference': input.variableName in self.timeshift_reference,
                    'type': self.components[input.componentName].inputs[input.variableName]['type']
                } for input in self.inputs
            ]
        }
        return exported_metadata

    def save_datalink_metadata(self, destination: Path | str) -> dict:
        """
        Saves metadata for pipeline input variables.
        This method saves metadata for the AI Inference Server into a YAML file.
        This metadata determines how the AI Inference Server feeds input to the pipeline, especially inter-signal alignment.
        The file is created in the `destination` folder with the name `datalink_metadata.yml`

        Args:
            destination (path-like): Path of the destination directory.
        """
        datalink_metadata = self.get_datalink_metadata()
        with open(Path(destination) / DATALINK_METADATA, "w", encoding="utf8") as f:
            yaml.dump(datalink_metadata, f, sort_keys=False)
        return datalink_metadata

    def get_runtime_config(self) -> dict:
        runtime_config_components = []
        for component_name in self.components:
            component = self.components[component_name]
            if isinstance(component, PythonComponent):
                runtime_config_components.append({
                    "name": component_name,
                    "device": "IED1",
                    "targetRuntime": "Python",
                })
            else:
                runtime_config_components.append({
                    "name": component_name,
                    "device": "IED1",
                    "targetRuntime": "gpuruntime",
                })
        return {
            "fileFormatVersion": "1",
            "runtimeInfo": {
                "projectName": self.name,
                "runtimeConfigurationVersion": "1.0.0",
                "createdOn": timestamp_aiis_compatible(),
            },
            "runtimeConfiguration": {
                "devices": [{
                    "name": "IED1",
                    "address": "localhost",  # Optional
                    "arch": "x86_64",  # Optional
                }],
                "components": runtime_config_components,
            },
        }

    def save_runtime_config(self, destination: Path | str) -> dict:
        """
        Save runtime configuration to a specified destination.

        Args:
            destination: The path where the runtime configuration should be saved.

        Returns:
            dict: The runtime configuration dictionary that was saved.
        """
        runtime_config = self.get_runtime_config()
        with open(Path(destination) / RUNTIME_CONFIG, "w", encoding="utf8") as f:
            yaml.dump(runtime_config, f, sort_keys=False)
        return runtime_config

    def save_telemetry_data_if_consented(self, destination: Path):
        try:
            Path(destination / TELEMETRY_YAML).unlink(missing_ok=True)
            # checking whether the user has made a statement about telemetry collection
            if is_telemetry_allowed():
                self.save_telemetry_data(destination)
        except RuntimeError as consent_is_undecided:
            raise consent_is_undecided

    def save_telemetry_data(self, destination: Path):
        """
        Save telemetry data to a specified destination.

        Args:
            destination (Path): The path where the telemetry data should be saved.
        """

        telemetry_path = destination / TELEMETRY_YAML
        telemetry_data = {}

        try:
            consent_allowed = is_telemetry_allowed()
        except RuntimeError:
            consent_allowed = "undecided"

        try:
            consent_data, _ = read_telemetry_consent_file()
        except BaseException:
            consent_data = {}

        telemetry_data["telemetry_consent"] = {}
        telemetry_data["telemetry_consent"][CONSENT_KEY] = consent_allowed
        telemetry_data["telemetry_consent"][CONSENT_KEY_SDK] = consent_data.get(CONSENT_KEY_SDK, 'unknown')
        telemetry_data["telemetry_consent"][CONSENT_KEY_TS] = consent_data.get(CONSENT_KEY_TS, 'unknown')
        telemetry_data["telemetry_consent"][CONSENT_KEY_METHOD] = consent_data.get(CONSENT_KEY_METHOD, get_consent_source())

        telemetry_data["platform"] = {}
        telemetry_data["platform"]["os"] = platform.system()
        telemetry_data["platform"]["release"] = platform.release()
        telemetry_data["platform"]["python_version"] = platform.python_version()

        _logger.info(f"locals: {locals()}")
        telemetry_data["environment"] = {}
        env_info = "Jupyter" if any(k for k in locals() if k in ["__IPYTHON__", "get_ipython"]) else MSG_NOT_FOUND
        env_info = "GitLab CI/CD" if "GITLAB_CI" in os.environ else env_info
        env_info = "Azure DevOps Pipelines" if "TF_BUILD" in os.environ else env_info
        env_info = "GitHub Actions" if "GITHUB_ACTIONS" in os.environ else env_info
        telemetry_data["environment"]["info"] = env_info

        telemetry_data["industrial_ai"] = {}
        try:
            telemetry_data["industrial_ai"]["simaticai"] = importlib_metadata.version("simaticai")
        except importlib_metadata.PackageNotFoundError:
            telemetry_data["industrial_ai"]["simaticai"] = MSG_NOT_FOUND
            _logger.debug("simaticai package not found")

        telemetry_data["pipeline"] = {}
        telemetry_data["pipeline"]["python_versions"] = list(set(self.components[component].python_version for component in self.components
                                                                 if isinstance(self.components[component], PythonComponent)))
        telemetry_data["pipeline"]["file_extensions"] = list(set(f.suffix for f in Path(destination).rglob("*")
                                                                 if f.suffix not in ["", ".zip", ".yml", ".yaml", ".html"]))
        with open(telemetry_path, 'w') as telemetry_file:
            yaml.dump(telemetry_data, telemetry_file)

    def validate(self, destination: str | Path = "."):
        """
        Validates whether the package configuration is compatible with the expected runtime environment.

        The method verifies:

        - If the package has at least one component
        - If all wires create connections between existing components and their variables
        - If metadata is defined and valid.
        - If a package with the same name already exists in the `destination` folder. In this case a warning message appears and the `save(..)` method overwrites the existing package.
        - If the package has multiple components and if they are using the same Python version

        Args:
            destination (str, optional): Path of the expected destination folder. Defaults to ".".
        """
        version = self.save_version if self.save_version is not None else self.init_version

        if len(self.components) < 1:
            raise AssertionError("The package must have at least one component.")

        for p_output in self.outputs:
            if self.components[p_output.componentName].batch.outputBatch:
                raise AssertionError(f"The component '{p_output.componentName}' has pipeline output defined with variable name '{p_output.variableName}'. \
                                      None of component with pipeline output is allowed to provide batch output.")

        for wire_hash in self.wiring.copy():
            wire = self.wiring[wire_hash]
            self._check_wiring(wire, wire_hash)

        pipeline_inputs = [p_input.variableName for p_input in self.inputs]
        pipeline_outputs = [p_output.variableName for p_output in self.outputs]
        if any(variable in pipeline_outputs for variable in pipeline_inputs):
            conflicts = set(pipeline_inputs).intersection(set(pipeline_outputs))
            raise AssertionError(f"Pipeline input and output variables must be unique. Conflicting variables: {conflicts}")

        self._check_timeshifting()
        self._get_validated_rib_cycle_time(self.rib_cycle_time)
        self._check_supported_types_for_connections()

        package_path = Path(destination) / f"{self.name}_{version}".replace(" ", "-")
        if package_path.is_dir():
            _logger.warning(f"Target folder ({package_path}) already exists! Unless changing the package name the package could be invalid and your files will be overwritten!")

        python_versions = set()

        for component in self.components:
            if isinstance(self.components[component], PythonComponent):
                python_versions.add(self.components[component].python_version)

        if (1 < len(python_versions)):
            _logger.warning("The use of multiple python version in a single pipeline is not recommended. We recommend using only one of the supported versions, which are Python 3.11 or 3.12.")

        _logger.info(f"Package '{self.name}' is valid and ready to save.")

    def _check_timeshifting(self):
        if len(self.timeshift_reference) > 0 and self.periodicity is None:
            raise AssertionError("When using inter signal alignment reference variables, the periodicity must be set.")

    def _check_supported_types_for_connections(self):
        for p_input in self.inputs:
            variable_type = self.components[p_input.componentName].inputs[p_input.variableName]['type']
            warnings, errors = p_input.check_connection_type_compatibility(variable_type)
            warnings_str = ", ".join(warnings)
            errors_str = ", ".join(errors)
            if warnings:
                _logger.warning(f"Input variable `{p_input.variableName}` of component `{p_input.componentName}` is of type "
                                f"`{variable_type}` which is not supported for connection type `{p_input.connection.cptype.name}`. "
                                f"Issues: {warnings_str}.")
            if errors:
                _logger.error(f"Input variable `{p_input.variableName}` of component `{p_input.componentName}` is of type "
                              f"`{variable_type}` which is not supported for connection type `{p_input.connection.cptype.name}`. "
                              f"Issues: {errors_str}.")

        for p_output in self.outputs:
            variable_type = self.components[p_output.componentName].outputs[p_output.variableName]['type']
            warnings, errors = p_output.check_connection_type_compatibility(variable_type)
            warnings_str = ", ".join(warnings)
            errors_str = ", ".join(errors)
            if warnings:
                _logger.warning(f"Output variable `{p_output.variableName}` of component `{p_output.componentName}` is of type "
                                f"`{variable_type}` which is not supported for connection type `{p_output.connection.cptype.name}`. "
                                f"Issues: {warnings_str}.")
            if errors:
                _logger.error(f"Output variable `{p_output.variableName}` of component `{p_output.componentName}` is of type "
                              f"`{variable_type}` which is not supported for connection type `{p_output.connection.cptype.name}`. "
                              f"Issues: {errors_str}.")
        for p_param in self.parameters:
            if isinstance(p_param, SecretPipelineParameter):
                continue
            if not p_param.topicBased:
                continue
            if not p_param.has_valid_connection():
                _logger.error(f"Pipeline parameter `{p_param.name}` is of type `{p_param.dtype}` which is not supported for connection type `{p_param.connection.cptype.name}`.")

    def _check_wiring(self, wire, wire_hash):
        error_messages = []
        if wire['fromComponent'] not in self.components:
            error_messages.append(f"From component {wire['fromComponent']} does not exist")
        if wire['toComponent'] not in self.components:
            error_messages.append(f"To component {wire['toComponent']} does not exist")
        if wire['fromOutput'] not in self.components[wire['fromComponent']].outputs:
            error_messages.append(f"Output variable {wire['fromOutput']} does not exist on component {wire['fromComponent']}")
        if wire['toInput'] not in self.components[wire['toComponent']].inputs:
            error_messages.append(f"Input variable {wire['toInput']} does not exist on component {wire['toComponent']}")
        if len(error_messages) == 0:
            from_type_ = self.components[wire['fromComponent']].outputs[wire['fromOutput']]['type']
            to_type_ = self.components[wire['toComponent']].inputs[wire['toInput']]['type']
            if from_type_ != to_type_:
                error_messages.append(f"The types of input and output variables does not match for wiring {wire_hash}.")
        if len(error_messages) > 0:
            self.wiring.pop(wire_hash)
            error_messages.append("The wire has been deleted, please check the variables and re-create the connection.")
            raise AssertionError(error_messages.__str__())

    @staticmethod
    def _get_validated_rib_cycle_time(rib_cycle_time):

        if rib_cycle_time is None:
            return None

        if isinstance(rib_cycle_time, (int, float)):
            rib_cycle_time = int(rib_cycle_time)

            if rib_cycle_time <= 0:
                raise ValueError(rib_cycle_time_error_message)
            if rib_cycle_time < 1000 or rib_cycle_time > 1_000_000:
                _logger.warning(rib_cycle_time_warning_message)
        else:
            raise ValueError(rib_cycle_time_error_message)

        return rib_cycle_time

    def save(self, destination: str | Path = ".", package_id: Optional[uuid.UUID] = None, version: Optional[str] = None) -> Path:
        """
        @Deprecated, reason: only edge package generation will be supported in the future. Use export instead.

        Saves the assembled package in a zip format.
        The name of the file is defined as `{package_name}_{package_version}.zip`.
        If a file with such a name already exists in the `destination` folder, it gets overwritten and a warning message appears.

        The package is also available as a subfolder on the destination path with the name `{package_name}_{package_version}`.
        If the assembled content does not meet the expected one, this content can be changed and simply packed into a zip file.

        The package contains files and folders in the following structure:

        - Package folder with name `{package_name}_{package_version}`
            - `datalink-metadata.yml`
            - `pipeline-config.yml`
            - Component folder with name `{component_name}`

            When the component is a `PythonComponent`, this folder contains:

            - `requirements.txt`
            - Entrypoint script defined by the entrypoint of the component
            - Extra files as added to the specified folders
            - Source folder with name `src` with necessary python scripts

        If a package ID is specified, and a package with the same ID and version is already present in the `destination` folder,
        an error is raised.

        Args:
            destination (str, optional): Target directory for saving the package. Defaults to ".".
            package_id (UUID): The optional package ID. If None, a new UUID is generated.
        """

        try:
            # checking whether the user has made a statement about telemetry collection
            is_telemetry_allowed()
        except RuntimeError as consent_is_undecided:
            raise consent_is_undecided

        self._set_save_version_and_package_id(Path(destination), package_id, version)

        destination = Path(destination)
        self.validate(destination)
        name = self.name.replace(" ", "-")
        package_name = f"{name}_{self.save_version}"

        destination = destination / package_name
        destination.mkdir(parents=True, exist_ok=True)

        for component in self.components:
            self.components[component].save(destination, False)
            if isinstance(self.components[component], PythonComponent):
                self.report_writer.add_direct_dependencies(self.components[component].name, self.components[component].python_dependencies.dependencies)

        self.save_datalink_metadata(destination)
        self.save_pipeline_config(destination)
        p_page.save_readme_html(self, destination)
        self.save_telemetry_data_if_consented(destination)

        zip_destination = shutil.make_archive(
            base_name=str(destination.parent / package_name), format='zip',
            root_dir=destination.parent, base_dir=package_name,
            verbose=True, logger=_logger)

        return Path(zip_destination)

    def _set_save_version_and_package_id(self, destination: Path, package_id: Optional[uuid.UUID], version: Optional[str]):
        """
        @Deprecated, reason: only used when saving a `Pipeline Configuration Package` with the `save()` method, which is deprecated. Use `export()` instead.
        """

        previous_versions_and_ids = self._get_versions_and_package_ids_of_existing_packages(destination)
        previous_versions, previous_package_ids = zip(*previous_versions_and_ids) if previous_versions_and_ids else ([], [])

        # if package id is provided, we use that
        if package_id is not None:
            self.package_id = package_id
        # if not, we auto-generate a package id
        else:
            previous_package_ids_set = {pkg_id for pkg_id in previous_package_ids if pkg_id is not None}
            if self.package_id is not None:
                previous_package_ids_set.add(self.package_id)

            if len(previous_package_ids_set) == 0:
                self.package_id = uuid.uuid4()
            elif len(previous_package_ids_set) == 1:
                self.package_id = previous_package_ids_set.pop()
            else:
                _logger.error(f"Multiple package IDs found in the destination folder: {previous_package_ids_set}. Set a package ID.")
                raise RuntimeError(f"Multiple package IDs found in the destination folder: {previous_package_ids_set}. Set a package ID.")

        # Preference #1: use the provided version
        if version is not None:
            self.save_version = version
        # Preference #2: use the version set at init time
        elif self.init_version is not None:
            self.save_version = self.init_version
        # Preference #3: auto-generate version
        else:
            previous_decimal_versions_set = {int(v) for v in previous_versions if v is not None and v.isdecimal()}
            if len(previous_decimal_versions_set) == 0:
                self.save_version = "1"
            else:
                self.save_version = str(max(previous_decimal_versions_set) + 1)

        # checking if the package zip already exists
        name = self.name.replace(" ", "-")
        package_name = f"{name}_{self.save_version}"
        package_file = destination / f"{package_name}.zip"
        if package_file.exists():
            _logger.warning(f"Target package with version '{self.save_version}' already exists: '{package_file}. The package will be overwritten.")
        edge_package_file = destination / f"{name}-edge_{self.save_version}.zip"
        if edge_package_file.exists():
            _logger.warning(f"Target package with version '{self.save_version}' already exists: '{edge_package_file}. The package will be overwritten.")

        self.version = self.save_version

    def _get_versions_and_package_ids_of_existing_packages(self, destination: Path) -> List[Tuple[str, Optional[uuid.UUID]]]:
        """
        @Deprecated, reason: only used when saving a `Pipeline Configuration Package` with the `save()` method, which is deprecated. Use `export()` instead.
        """

        package_versions_and_ids = []
        for file in destination.glob(f"{self.name.replace(' ', '-')}*.zip"):
            with zipfile.ZipFile(file) as zip_file:
                config_path = [f for f in zip_file.namelist() if f.endswith(PIPELINE_CONFIG)]
                if len(config_path) == 0:
                    continue
                config_path = config_path[0]
                with zip_file.open(config_path) as config_file:
                    config = yaml.load(config_file, Loader=yaml.SafeLoader)
                    pipeline_info = config.get("dataFlowPipelineInfo", {})
                    name = pipeline_info.get("projectName", None)
                    if name is None or name != self.name:
                        continue
                    version = pipeline_info.get("dataFlowPipelineVersion", None)
                    package_id = pipeline_info.get("packageId", None)
                    package_id = uuid.UUID(package_id) if package_id is not None else None
                    package_versions_and_ids.append((version, package_id))
        return package_versions_and_ids

    def _add_parameter(self, parameter: PipelineParameter | SecretPipelineParameter):
        if any(param.name == parameter.name for param in self.parameters):
            raise AssertionError(f"Parameter with name '{parameter.name}' already exists in the pipeline.")
        if parameter is None:
            raise AssertionError("Parameter cannot be None.")
        self.parameters.append(parameter)

    def add_secret_parameter(self, name: str, desc: str | None = None):
        """
        Adds a secret parameter to the pipeline configuration.

        Args:
            name (str): Name of the secret parameter. Must contain only letters, digits, underscores, and hyphens. Cannot start with `__AI_IS_` prefix.
            desc (str, optional): Description of the secret parameter. Must be a string between 3 and 60 characters if provided.

        Raises ValueError if the conditions for name or description are not met.
        """
        self._add_parameter(SecretPipelineParameter(name=name, description=desc))

    def add_parameter(self, name: str, default_value, type_name: str = "String", topic_based: bool = False, desc: str = None):
        """
        Adds a parameter to the pipeline configuration, which alters the behavior of the pipeline.
        The parameter's default value and its properties are saved in the pipeline configuration
        and the value of the parameter can later be changed on AI Inference Server.

        Args:
            name (str): Name of the parameter
            desc (str): Description of the parameter (optional)
            type_name (str, optional): Data type of the parameter. Defaults to "String".
            default_value (str): Default value of the parameter
            topic_based (bool, optional): If true, the parameter can be updated from a message queue.

        Raises:

            ValueError:
                When:
                - the default value of the parameter is not of the specified data type (`type_name`) or
                - the specified data type itself is not an allowed data type (not a part of `parameter_types` dict) or
                - the specified data type is not given in the right format or
                - the type of the given `topic_based` parameter is not `bool`.
                - the name of the parameter starts with `__AI_IS_` prefix. These are reserved parameters by AI Inference Server
        """
        self._add_parameter(PipelineParameter(
            name=name,
            defaultValue=default_value,
            dtype=type_name,
            topicBased=topic_based,
            description=desc))

    def save_pipeline_manifest(self, pipeline_dir, exported_components):
        contents_yaml = {
            "totalSizeInBytes": sum(c["sizeInBytes"] for c in exported_components.values()),
            "components": exported_components
        }
        with open(pipeline_dir / PIPELINE_CONTENT, "w", encoding="utf8") as f:
            yaml.dump(contents_yaml, f, sort_keys=False)

    def save_checksum(self, edge_package_path: Path):
        sha256_hash = calc_sha(edge_package_path)
        sha_format = f"{sha256_hash}  {edge_package_path.name}"
        edge_package_path.with_suffix('.sha256').write_text(sha_format)

    def _parse_package_info(self, zip_path: Path, zip_file):
        config_path = next(f for f in zip_file.namelist() if f.endswith(PIPELINE_CONFIG))
        with zip_file.open(config_path) as config_file:
            pipeline_config = yaml.load(config_file, Loader=yaml.SafeLoader)
        pipeline_info = pipeline_config["dataFlowPipelineInfo"]
        package_id = pipeline_info["packageId"]
        pipeline_name = pipeline_info["projectName"]
        pipeline_version = pipeline_info["dataFlowPipelineVersion"]
        pipeline_type = pipeline_config.get("packageType", 'full')
        pipeline_originVersion = pipeline_version
        if pipeline_type == 'delta':
            pipeline_originVersion = pipeline_config.get("originVersion", pipeline_version)
        format_version = pipeline_config.get("fileFormatVersion", '1.0.0')
        has_manifest = 0 <= compare_versions(format_version, '1.3.0')
        if has_manifest:
            with zip_file.open(PIPELINE_CONTENT) as contents:
                pipeline_contents = yaml.load(contents, Loader=yaml.SafeLoader)
        return {
            "file": zip_path,
            "name": pipeline_name,
            "packageId": package_id,
            "version": pipeline_version,
            "originVersion": pipeline_originVersion,
            "type": pipeline_type,
            "pipeline_config": pipeline_config,
            "has_manifest": has_manifest,
            "contents": pipeline_contents if has_manifest else {},
        }

    def _read_package_info_from_zip(self, zip_path: Path):
        try:
            with zipfile.ZipFile(zip_path) as zip_file:
                package_info = self._parse_package_info(zip_path, zip_file)
                package_id = package_info["packageId"]
                pipeline_name = package_info["name"]
                pipeline_version = package_info["version"]
                if (self.package_id is not None and package_id != str(self.package_id)) \
                   or self.name != pipeline_name \
                   or pipeline_version is None:
                    return None
                return package_info
        except BaseException as e:
            _logger.warning(f"Failed to read pipeline configuration from zip file '{zip_path}': {e}")
        return None

    def _previously_exported_packages(self, destination: Path):
        pipeline_zip_files = Path(destination).glob(f"{self.name.replace(' ', '-')}-edge_*.zip")
        pipeline_zip_files = [self._read_package_info_from_zip(f) for f in pipeline_zip_files]
        pipeline_zip_files = [f for f in pipeline_zip_files if f is not None]
        pipeline_zip_files.sort(key=cmp_to_key(lambda a, b: compare_versions(a["version"], b["version"])), reverse=True)
        return pipeline_zip_files

    def _find_latest_full_package_and_version(self, destination: Path):
        prev_packages = self._previously_exported_packages(destination)
        if len(prev_packages) == 0:
            return None
        latest_delta_package_version = prev_packages[0]['version']
        for package in prev_packages:
            if package['type'] == 'full':
                if not package["has_manifest"]:
                    return None
                package['originVersion'] = package['version']
                package['version'] = latest_delta_package_version
                return package
        return None

    def _did_python_env_change_in_any_component(self, previous_package) -> bool:
        if previous_package is None:
            return True
        for component_name in self.components:
            component: Component = self.components[component_name]
            if isinstance(component, PythonComponent):
                prev_config = previous_package["pipeline_config"]
                prev_component = [c for c in prev_config["dataFlowPipeline"]["components"] if c["name"] == component_name]
                if len(prev_component) == 0:
                    return True
                prev_python_version = prev_component[0]["runtime"]["version"]
                if 0 != compare_versions(prev_python_version, component.python_version):
                    return True
                prev_requirements = previous_package['contents']['components'][component_name]['requirements'] if previous_package["has_manifest"] else []
                current_requirements = [ str(rq) for _,rq in component.python_dependencies.dependencies.items()]
                if set(prev_requirements) != set(current_requirements):
                    return True
        return False

    def _validate_export_params(self,
                                package_id: uuid.UUID | None = None, version: str | None = None,
                                delta_threshold_mb: int | float = 300, package_type: str = "auto"):
        # Tracks whether caller explicitly set export(version=...).
        self._export_version_explicit = version is not None

        try:
            # checking whether the user has made a statement about telemetry collection
            is_telemetry_allowed()
        except RuntimeError as consent_is_undecided:
            raise consent_is_undecided

        if not isinstance(delta_threshold_mb, (int, float)) or delta_threshold_mb <= 0:
            raise ValueError("Invalid threshold value. Delta threshold must be a positive number representing megabytes.")

        if package_type not in ["auto", "full", "delta", "fine-grained-delta"]:
            raise ValueError("Invalid package type. Must be one of: 'auto', 'full', 'delta'.")

        if package_id is not None:
            # If package_id is None, the latest package_id will be reused or a new one will be generated. But if package_id is provided, it must be valid.
            if isinstance(package_id, str):
                try:
                    self.package_id = uuid.UUID(package_id)
                except ValueError:
                    raise ValueError(f"Invalid package_id: '{package_id}' is not a valid UUID string")
            elif isinstance(package_id, uuid.UUID):
                self.package_id = package_id
            else:
                raise ValueError("Invalid package_id: must be either None, a UUID object or a valid UUID string")

        # Preference #1: use the provided version
        if version is not None:
            # Validate version string
            version_invalid = False
            if not isinstance(version, (int, float, str)):
                version_invalid = True
            else:
                version = f"{version}"
                parts = version.split('.')
                version_invalid = len(parts) > 3 or not all(part.isdigit() for part in parts)

            if version_invalid:
                raise ValueError(f"Invalid version: '{version}' must be a string in the format 'X', 'X.Y', or 'X.Y.Z' where X, Y, Z are integers")

            self.save_version = version

        # Preference #2: use the version set in the constructor
        elif self.init_version is not None:
            self.save_version = f"{self.init_version}"
        else:
            self.save_version = "1"

    def _decide_delta(self, previous_package, delta_threshold_mb: int | float, package_type: str) -> Tuple[bool, str]:
        name = self.name.replace(" ", "-")
        should_create_delta = False

        if previous_package is None:
            if package_type == 'delta':
                raise AssertionError("Cannot create a delta package without a full package. Please create a full package first.")
        else:
            python_env_changed = self._did_python_env_change_in_any_component(previous_package)
            if package_type == 'delta':
                should_create_delta = True
                if python_env_changed:
                    raise AssertionError("The Python environment has changed since the last export. Cannot create a delta package. Please create a new full package.")
            if package_type == 'auto' and not python_env_changed:
                # convert MB to Bytes, because stat().st_size returns size in Bytes
                delta_threshold = int(delta_threshold_mb * 1000 * 1000)
                should_create_delta = delta_threshold <= previous_package["contents"]["totalSizeInBytes"]
            if package_type == 'fine-grained-delta':
                should_create_delta = True

            self.package_id = previous_package["packageId"]
            # Keep explicit export(version=...) unchanged; only auto-increment when version was not explicitly provided.
            if not self._export_version_explicit:
                self.save_version = increment_version(previous_package["version"])

        if should_create_delta:
            component_package_type = package_type
            self.package_type = "delta"
            self.origin_version = previous_package["originVersion"]
            edge_package_name = f"{name}-edge_delta_{self.save_version}"
            _logger.warning("WARNING! Package size is over the delta threshold, a delta package will be created automatically.")
        else:
            component_package_type = "full"
            if self.package_id is None:
                self.package_id = uuid.uuid4()
            edge_package_name = f"{name}-edge_{self.save_version}"

        return edge_package_name, component_package_type

    def export(self, destination: str | Path = ".",
               package_id: uuid.UUID | None = None, version: str | None = None,
               clean_up: bool = True,
               delta_threshold_mb: int | float = 300, package_type: str = "auto") -> Path:
        """
        Exports the pipeline as an edge configuration package (ZIP file).

        This method validates the pipeline, exports all components, and generates a deployment-ready
        edge package. The package includes component files, dependencies, pipeline configuration,
        runtime configuration, and a generated README. A SHA256 checksum is also created for integrity verification.

        Args:
            destination (str | Path, optional): Directory path where the package will be exported.
                Defaults to current directory ("."). The exported edge package will be created as
                `{destination}/{name}-edge_{version}.zip` or `{destination}/{name}-edge_delta_{version}.zip` for delta packages.
            package_id (uuid.UUID | None, optional): Unique identifier for the package. If not provided,
                the UUID of the previous package with the same name will be reused. For a new full package,
                a new UUID is generated. Defaults to None.
            version (str | None, optional): Version string for the package. If not provided, the version
                of the previous package with the same name and UUID will be auto-incremented. If no previous package exists,
                defaults to 1.
            clean_up (bool, optional): If True, removes the temporary pipeline directory after creating
                the edge package. If False, keeps the temporary directory. Defaults to True.
            delta_threshold_mb (int | float, optional): Size threshold in megabytes for automatically creating
                delta packages. If a previous full package exists and its size exceeds this threshold,
                a delta package will be created when package_type is 'auto' or 'delta'. Must be a positive number.
                Defaults to 300 MB.
            package_type (str, optional): Type of package to create. Valid options are:
                - 'auto': Automatically determines the best package type based on previous packages and delta threshold.
                - 'full': Creates a complete package with all files and dependencies.
                - 'delta': Creates an incremental package relative to the latest full package. Raises an error if no full package exists.
                - 'fine-grained-delta': Creates a delta package with fine-grained component-level changes.
                Defaults to 'auto'.

        Returns:
            Path: Path to the generated edge configuration package ZIP file.

        Raises:
            RuntimeError: If telemetry consent status cannot be determined.
            AssertionError: If Python version validation fails in a component, if delta package is requested without a full package,
                or if Python environment has changed when creating a delta package.
            ValueError: If pipeline validation fails or if invalid arguments are provided (invalid package_type or delta_threshold_mb).

        Notes:
            - GPU dependencies automatically limit parallel execution to a single thread to avoid resource conflicts.
            - When the pipeline was created with the no-deps flag, Python components without transitive dependencies
              may cause runtime errors if not handled manually.
            - A package report is generated at `{destination}/{name}_{version}_package_report.md`.
            - SHA256 checksum file is created alongside the ZIP package for integrity verification.
            - Telemetry data may be included in the package if user consent is provided.
            - Delta packages require a previously exported full package with the same name and package_id.
            - If Python environment changes, a new full package must be created instead of a delta package.
        """

        destination = Path(destination)

        self._validate_export_params(package_id, version, delta_threshold_mb, package_type)
        self.validate(destination)

        previous_package = self._find_latest_full_package_and_version(destination)

        edge_package_name, component_package_type = self._decide_delta(previous_package, delta_threshold_mb, package_type)

        package_name = f"{self.name.replace(' ', '-')}_{self.save_version}"
        pipeline_dir = destination / package_name
        shutil.rmtree(pipeline_dir, ignore_errors=True)
        pipeline_dir.mkdir(parents=True, exist_ok=True)

        self.report_writer.set_path(destination / f"{package_name}_package_report.md")

        exported_components = {}
        for component_name in self.components:
            component: Component = self.components[component_name]
            _, component_manifest = component.export(pipeline_dir, component_package_type, previous_package, self.report_writer)
            exported_components[component_name] = component_manifest

        # For delta packages, add dependencies from the base package to the report
        if self.package_type == "delta" and previous_package is not None:
            for component_name in self.components:
                requirements_list = previous_package['contents']['components'][component_name].get('requirements', [])
                if requirements_list:
                    # Parse requirements into the format expected by report_writer
                    requirements_dict = {}
                    dependency_tuples = []
                    
                    for req_str in requirements_list:
                        # Extract package name (before operators or brackets)
                        package_name = re.split(r'[=<>!\[]', req_str)[0].strip()
                        requirements_dict[package_name] = req_str
                        
                        # Extract exact version (after ==)
                        if '==' in req_str:
                            version = req_str.split('==')[1].split(';')[0].split('[')[0].strip()
                            dependency_tuples.append((package_name, version))
                    
                    self.report_writer.add_direct_dependencies(component_name, requirements_dict)
                    self.report_writer.add_full_dependency_set(component_name, set(dependency_tuples))

        pipeline_config = self.save_pipeline_config(pipeline_dir)
        self.report_writer.set_pipeline_config(pipeline_config)

        self.save_datalink_metadata(pipeline_dir)
        self.save_runtime_config(pipeline_dir)
        p_page.save_readme_html(self, pipeline_dir)
        self.save_telemetry_data_if_consented(pipeline_dir)

        self.save_pipeline_manifest(pipeline_dir, exported_components)

        edge_package_path = Path(shutil.make_archive(
            base_name=str(destination / edge_package_name),
            format='zip',
            root_dir=pipeline_dir,
            verbose=True,
            logger=_logger))

        try:
            # check the package size and log warning or raise error if the size exceeds the limit
            _enforce_package_size(edge_package_path)
            self.save_checksum(edge_package_path)

        finally:
            self.report_writer.write_report()
            _logger.info(f"Report on {package_name} is saved to {pipeline_dir}.")
            if clean_up:
                shutil.rmtree(pipeline_dir)
        return edge_package_path


def convert_package(zip_path: Union[str, os.PathLike], report_writer: Optional[PipelineReportWriter] = None) -> Path:
    """
    @Deprecated, reason: only edge package generation will be supported in the future. Use Pipeline.export(...) instead.

    Create an Edge Configuration Package from a given Pipeline Configuration Package.

    If the input zip file is `{path}/{name}_{version}.zip`, the output file will be created as `{path}/{name}-edge_{version}.zip`.
    Please make sure that the given zip file comes from a trusted source!

    If a file with such a name already exists, it is overwritten.

    First, this method verifies that the requirements identified by name and version are either included
    in `PythonPackages.zip` or available on pypi.org for the target platform.

    Currently, the supported edge devices run Linux on 64-bit x86 architecture, so the accepted Python libraries are restricted to the platform independent ones and packages built for 'x86_64' platforms.
    AI Inference Server also provides a Python 3.11 and 3.12 runtime environment, so the supported Python libraries are restricted to Python 3.11 and 3.12 compatible packages.

    If for the target platform the required dependency is not available on pypi.org
    and not present in `PythonPackages.zip`,  it will log the problem at ERROR level.
    Then it downloads all dependencies (either direct or transitive), and creates a new zip
    file, which is validated against the AI Inference Server's schema.
    This functionality requires pip with version of 21.3.1 or greater.

    This method can be used from the command line too.
    Example usage:
    ```
    python -m simaticai convert_package <path_to_pipeline_configuration_package.zip>
    ```

    Args:
        zip_path (path-like): path to the pipeline configuration package zip file.
        report_writer (ReportWriter, optional): a ReportWriter object to write the report for a pipeline. Defaults to None.

    Returns:
        os.PathLike: The path of the created zip file.

    Exceptions:
        PipelineValidationError: If the validation fails. See the logger output for details.
    """

    try:
        # checking whether the user has made a statement about telemetry collection
        is_telemetry_allowed()
    except RuntimeError as consent_is_undecided:
        raise consent_is_undecided

    zip_path = Path(zip_path)
    if zip_path.stem.find('_') < 0:
        raise AssertionError("The input zip file name must contain an underscore character.")
    with tempfiles.OpenZipInTemp(zip_path) as zip_dir:
        top_level_items = list(zip_dir.iterdir())
        if len(top_level_items) != 1:
            raise AssertionError("The Pipeline Configuration Package must contain a single top level directory.")
        package_dir = zip_dir / top_level_items[0]
        runtime_dir = zip_dir / "edge_config_package"
        runtime_dir.mkdir(parents=True, exist_ok=True)
        config = yaml_helper.read_yaml(package_dir / PIPELINE_CONFIG)
        _validate_with_schema("input pipeline_config.yml", config, "pipeline.schema.json")
        runtime_config = _generate_runtime_config(config)
        if report_writer is not None:
            report_writer.set_path(Path(zip_path.parent / f"{zip_path.stem}_package_report.md"))
            report_writer.set_pipeline_config(config)

        for component in config['dataFlowPipeline']['components']:
            source_dir = package_dir / component["name"]

            if component["runtime"]["type"] == "python":
                python_version = component['runtime']['version']
                try:
                    python_version_validator(python_version)
                except ValueError as error:
                    raise AssertionError(error)

                pip_option_no_deps = component["runtime"].get("installTransitiveDependencies", True) is False
                if pip_option_no_deps:
                    _logger.warning(f"Component `{component['name']}` is requested to be installed without transitive dependencies. "
                                    "This may lead to runtime errors if the dependencies are not handled manually.")
                dependency_set = _package_component_dependencies(source_dir, python_version, pip_option_no_deps)

                # Check for GPU dependencies and set parallel steps (replicas) to 1 if necessary
                has_gpu_dependency = _check_for_gpu_dependencies(dependency_set)
                if has_gpu_dependency and component.get("replicas", 1) > 1:
                    _logger.warning(f"Component '{component['name']}' cannot have multiple parallel steps with GPU dependency, because of the GPU resource limitation. Setting parallel steps to 1.")
                    component["replicas"] = 1
                with open(package_dir / PIPELINE_CONFIG, "w") as f:
                    yaml.dump(config, f)

                if report_writer is not None:
                    report_writer.add_full_dependency_set(component_name=component["name"], dependency_set=dependency_set)
                runtime_config["runtimeConfiguration"]["components"].append({
                    "name": component["name"],
                    "device": "IED1",
                    "targetRuntime": "Python",
                })

            if component["runtime"]["type"] == "gpuruntime":
                runtime_config["runtimeConfiguration"]["components"].append({
                    "name": component["name"],
                    "device": "IED1",
                    "targetRuntime": "gpuruntime",
                })

            _package_component(source_dir, runtime_dir / 'components' / f"{component['name']}_{component['version']}")

        shutil.copy(str(package_dir / PIPELINE_CONFIG), str(runtime_dir / PIPELINE_CONFIG))
        datalink_metadata_yaml = package_dir / DATALINK_METADATA
        if datalink_metadata_yaml.is_file():
            shutil.copy(str(datalink_metadata_yaml), runtime_dir / DATALINK_METADATA)

        _validate_with_schema(f"generated {RUNTIME_CONFIG}", runtime_config, "runtime.schema.json")
        with open(runtime_dir / RUNTIME_CONFIG, "w", encoding="utf8") as file:
            yaml.dump(runtime_config, file)

        readme_html = package_dir / README_HTML
        if readme_html.exists():
            (runtime_dir / README_HTML).write_text(readme_html.read_text())

        telemetry_yaml = package_dir / TELEMETRY_YAML
        if telemetry_yaml.exists():
            (runtime_dir / TELEMETRY_YAML).write_text(telemetry_yaml.read_text())

        edge_package_path = Path(shutil.make_archive(
            # replacing the last occurrence of "_" with "-edge_".
            base_name=str(PurePath(zip_path).parent / "-edge_".join(zip_path.stem.rsplit("_", 1))),
            format='zip',
            root_dir=runtime_dir,
            verbose=True,
            logger=_logger))

        try:
            # check the package size and log warning or raise error if the size exceeds the limit
            _enforce_package_size(edge_package_path)
        finally:
            if report_writer is not None:
                report_writer.write_report()
                _logger.info(f"Report on {zip_path.stem} is saved to {zip_path.parent}.")

        sha256_hash = calc_sha(edge_package_path)
        sha_format = f"{sha256_hash}  {edge_package_path.name}"
        edge_package_path.with_suffix('.sha256').write_text(sha_format)

        return edge_package_path

def _enforce_package_size(edge_package_path: Path):
    package_size = edge_package_path.stat().st_size
    package_size_GB = "{:.2f}".format(package_size / 1000 / 1000 / 1000)
    package_size_soft_limit_GB = "{:.2f}".format(PACKAGE_SIZE_LIMIT / 1000 / 1000 / 1000)
    package_size_hard_limit_GB = "{:.2f}".format(PACKAGE_SIZE_HARD_LIMIT / 1000 / 1000 / 1000)

    if package_size > PACKAGE_SIZE_HARD_LIMIT:
        if edge_package_path.exists():
            edge_package_path.unlink()
        error_msg = f"ERROR! Pipeline package size {package_size} bytes ({package_size_GB} GB) exceeds the hard limit of " \
                    f"{PACKAGE_SIZE_HARD_LIMIT} bytes ({package_size_hard_limit_GB} GB). " \
                    "The package cannot be deployed to AI Inference Server. The zipped package file has been deleted. " \
                    "Please remove unnecessary files and dependencies and try again."
        _logger.error(error_msg)
        raise AssertionError(error_msg)

    elif package_size > PACKAGE_SIZE_LIMIT:
        warning_msg = f"WARNING! Pipeline package size {package_size} bytes ({package_size_GB} GB) exceeds the limit of " \
                      f"{PACKAGE_SIZE_LIMIT} bytes ({package_size_soft_limit_GB} GB). " \
                      "Earlier AI Inference Server versions (<2.9.0) may not support packages of this size. " \
                      "Please remove unnecessary files and dependencies if you are targeting AI Inference Server earlier than version 2.9.0."
        _logger.warning(warning_msg)

def _check_for_gpu_dependencies(dependency_set: set):
    dependency_set_names = [d.lower() for d, _ in dependency_set]
    has_gpu_dependency = next((True for dep in dependency_set_names if dep.startswith("nvidia-cuda")), False)
    return has_gpu_dependency


def _validate_with_schema(name: str, data: dict, schema_name: str):
    try:
        schema_path = module_resources.files("simaticai") / "data" / "schemas" / schema_name
        with schema_path.open("r", encoding="utf8") as schema_file:
            schema = json.load(schema_file)
            jsonschema.validate( instance=data, schema=schema)
    except jsonschema.exceptions.ValidationError as e:
        raise AssertionError(f"""Schema validation failed for {name} using '{schema_name}'!
        message: {e.message}
        """) from e
    except jsonschema.exceptions.SchemaError as e:
        raise AssertionError(f"""Schema error occurred for {name} using '{schema_name}'!
        message: {e.message}
        """) from e


def _package_component(source_dir, target_name):
    return shutil.make_archive(
        base_name=target_name,
        format='zip',
        root_dir=source_dir,
        verbose=True,
        logger=_logger)


def _package_component_dependencies(component_dir: Path, python_version: str, pip_option_no_deps: bool = False) -> set:
    python_packages_folder = component_dir / 'packages'
    requirements_file_path = component_dir / REQUIREMENTS_TXT
    packages_file = component_dir / PYTHON_PACKAGES_ZIP
    dependency_set = set()

    python_packages_folder.mkdir(exist_ok=True)

    if packages_file.is_file():
        with zipfile.ZipFile(packages_file) as zip_file:
            zip_file.extractall(python_packages_folder)
        packages_file.unlink()
    requirements_file_path.touch(exist_ok=True)
    try:
        dependency_set = create_wheelhouse(requirements_file_path, python_version, python_packages_folder, pip_option_no_deps)

        if any(Path(python_packages_folder).iterdir()):
            shutil.make_archive(
                base_name=str(component_dir / PYTHON_PACKAGES),
                format='zip',
                root_dir=python_packages_folder,
                verbose=True,
                logger=_logger)
    finally:
        shutil.rmtree(python_packages_folder)

    # This filtering needs to happen here, not in PythonDependencies,
    # because create_wheelhouse() still needs the original requirements.txt
    # with the extra index urls.
    with open(requirements_file_path, "r") as f:
        lines = f.readlines()
    filtered_lines = list(filter(lambda x: not (x.startswith("# Extra") or x.startswith("--extra-index-url") or x.startswith("# Index") or x.startswith("--index-url")), lines))
    with open(requirements_file_path, "w") as f:
        f.writelines(filtered_lines)

    return dependency_set


def _generate_runtime_config(pipeline_config: dict):
    project_name = pipeline_config["dataFlowPipelineInfo"]["projectName"]

    return {
        "fileFormatVersion": "1",
        "runtimeInfo": {
            "projectName": project_name,
            "runtimeConfigurationVersion": "1.0.0",
            "createdOn": timestamp_aiis_compatible(),
        },
        "runtimeConfiguration": {
            "devices": [{
                "name": "IED1",
                "address": "localhost",  # Optional
                "arch": "x86_64",  # Optional
            }],
            "components": [],
        },
    }
