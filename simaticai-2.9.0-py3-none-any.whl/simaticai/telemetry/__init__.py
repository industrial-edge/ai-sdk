"""
SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
SPDX-License-Identifier: MIT

Telemetry Consent Management Module

This module provides functionality for managing user consent for telemetry data collection
in the SIMATIC AI SDK. It implements a hierarchical consent system that respects user
privacy choices across multiple configuration methods.

Consent Decision Hierarchy:
    1. Session-level overrides (allow_telemetry_once/deny_telemetry_once)
    2. Environment variable (SIMATICAI_TELEMETRY)
    3. Configuration file (consent.yml in user config directory)

Key Features:
    - Persistent consent storage in YAML configuration files
    - Temporary session-level consent overrides
    - Environment variable support for CI/CD pipelines
    - Command-line interface for consent management
    - Automatic tracking of consent method, timestamp, and SDK version

Usage:
    Check if telemetry is allowed:
        >>> from simaticai.telemetry import is_telemetry_allowed
        >>> if is_telemetry_allowed():
        ...     # Send telemetry data
        ...     pass

    Set consent programmatically (persistent):
        >>> from simaticai.telemetry import allow_telemetry, deny_telemetry
        >>> allow_telemetry()  # Save consent to config file
        >>> deny_telemetry()   # Save denial to config file

    Set consent for current session only:
        >>> from simaticai.telemetry import allow_telemetry_once, deny_telemetry_once
        >>> allow_telemetry_once()  # Temporary, not saved
        >>> deny_telemetry_once()   # Temporary, not saved

    Via environment variable:
        $ export SIMATICAI_TELEMETRY=true
        $ python my_script.py

    Via command line:
        $ simaticai telemetry --allow
        $ simaticai telemetry --deny
        $ simaticai telemetry --status

Configuration File:
    The consent configuration is stored in a platform-specific user configuration
    directory (e.g., ~/.config/simaticai/consent.yml on Linux) and includes:
    - User's consent decision (allow_telemetry: true/false)
    - Timestamp of the decision
    - SDK version at time of consent
    - Method used to provide consent
    - Full consent information text

Exception Handling:
    If no consent decision has been made, calling is_telemetry_allowed() will raise
    a RuntimeError prompting the user to provide consent via the CLI command:
        $ simaticai telemetry

"""
