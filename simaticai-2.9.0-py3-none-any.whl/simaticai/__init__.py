"""
SPDX-FileCopyrightText: Copyright (C) 2021 Siemens AG
SPDX-License-Identifier: MIT

SIMATIC AI SDK Package

The AI Software Development Kit, or AI SDK for short, is an essential part of
Siemens' Industrial Edge ecosystem. It is a set of Python libraries that
provide building blocks for automating the creation, packaging, and testing of
inference pipelines for the AI Inference Server.

The AI SDK is accompanied by end-to-end tutorials that deploy notebook-based
workflows for training models, packaging them for deployment, and testing
those packages. The AI SDK assumes a machine-learning workflow that includes
the following steps:

- Training data preparation
- Training models
- Packaging models as an inference pipeline
- Testing of packaged inference pipelines
- Generating the inference pipeline for AI@Edge
"""
