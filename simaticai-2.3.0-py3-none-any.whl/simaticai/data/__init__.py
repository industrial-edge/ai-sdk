# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

"""
This module contains additional files for AI SDK.

These files are necessary for some functionalities of the SDK.
"""
