#include "..\..\C\7zVersion.h"

#undef MY_COPYRIGHT
#undef MY_VERSION_COPYRIGHT_DATE
#define MY_COPYRIGHT "Copyright (c) 1999-2011 Igor Pavlov"
#define MY_VERSION_COPYRIGHT_DATE MY_VERSION "  " MY_COPYRIGHT "  " MY_DATE
