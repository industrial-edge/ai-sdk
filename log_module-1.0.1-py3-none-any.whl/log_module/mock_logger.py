# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

"""
A logger facade for testing.

This module can substitute the AI Inference Server's
logger in development and testing environments.
Each method prefixes the message with '[PY] ' and delegates to
the standard Python logger.

Limitation: The log methods can only accept a single string
argument. As composition from multiple arguments is not
supported on the Edge runtime, it is not supported in this module either.
"""

import logging
import os


class LogModule:
    """
    Facade class for exposing the AI Inference Server's log methods.

    This class can be imported and used the same way as on the Edge device.

    Example usage::

        from log_module import LogModule
        logger = LogModule()

        def run(data: str):
            logger.trace("trace from EMBEDDED Python")
            logger.info("info from EMBEDDED Python")
            logger.warning("warning from EMBEDDED Python")
            logger.warn("warn from EMBEDDED Python")
            logger.debug("debug from EMBEDDED Python")
            logger.error("error from EMBEDDED Python")
            logger.critical("critical from EMBEDDED Python")
            return {"ready": False, "output": None}
    """

    def __init__(self):
        self.TRACE_LEVEL = 5
        logging.addLevelName(self.TRACE_LEVEL, "TRACE")
        loglevel = os.environ.get("LOGLEVEL", "DEBUG").upper()
        if loglevel not in ["TRACE", "INFO", "WARNING", "ERROR", "CRITICAL"]:
            loglevel = "DEBUG"
        logging.basicConfig(level=loglevel)
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(loglevel)

    def trace(self, message):
        """
        Logs a message on TRACE level.

        Args:
            message (str): The log message
        """
        if self.logger.isEnabledFor(self.TRACE_LEVEL):
            self.logger.log(self.TRACE_LEVEL, _prefix(message))

    def debug(self, message):
        """
        Logs a message on DEBUG level.

        Args:
            message (str): The log message
        """
        self.logger.debug(_prefix(message))

    def info(self, message):
        """
        Logs a message on INFO level.

        Args:
            message (str): The log message
        """
        self.logger.info(_prefix(message))

    def warning(self, message):
        """
        Logs a message on WARNING level.

        Args:
            message (str): The log message
        """
        self.logger.warning(_prefix(message))

    def warn(self, message):
        """
        Logs a message on WARNING level.

        Args:
            message (str): The log message
        """
        self.warning(message)

    def error(self, message):
        """
        Logs a message on ERROR level.

        Args:
            message (str): The log message
        """
        self.logger.error(_prefix(message))

    def critical(self, message):
        """
        Logs a message on CRITICAL level.

        Args:
            message (str): The log message
        """
        self.logger.critical(_prefix(message))


def _prefix(message):
    return f"[PY] {message}"
