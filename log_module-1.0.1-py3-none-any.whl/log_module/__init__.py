# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

"""
## Logging in AI Inference Server

The AI Inference Server's Python runtime provides a logger module
which is embedded in the runtime and not available as a separate
Python module. The AI SDK's log_module mimics the behavior of this embedded
runtime logger by offering the same methods backed by the standard Python
logging framework.

This module is not a real logging framework, it only exists to
help you write code against the logging framework on the Edge device.

Using the AI SDK's LocalPipelineRunner the log_module wheel is
automatically provided during the test run. If you want to run
your code containing calls to log_module without the LocalPipelineRunner,
you have to install the log_module wheel in your local execution
environment. You should not install log_module on the Edge device itself.

The log level can be set through the environment variable LOGLEVEL.
Possible values are: TRACE, DEBUG, INFO, WARNING, ERROR, CRITICAL.
Please note that this setting only applies for local testing.
For running on the Edge device, you can set the log level in the
AI Inference Server application.
"""

from .mock_logger import LogModule

__all__ = ("LogModule",)
