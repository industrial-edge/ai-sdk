# SPDX-FileCopyrightText: 2021-2025 Siemens AG
# SPDX-License-Identifier: MIT

"""
This module contains the schema files used in validation methods.

These JSON schema files describe the configuration YAML files' schema
for AI Inference Server.
"""
