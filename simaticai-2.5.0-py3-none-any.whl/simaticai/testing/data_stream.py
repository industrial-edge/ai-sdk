# SPDX-FileCopyrightText: 2021-2025 Siemens AG
# SPDX-License-Identifier: MIT

class DataStream:
    """
    Base class for datastream generators
    """

    def __iter__(self):
        """
        Empty generator method for child classess to implement.
        """
        raise NotImplementedError('Child classes must implement this method.')
