# SPDX-FileCopyrightText: 2021-2025 Siemens AG
# SPDX-License-Identifier: MIT

"""
Pipeline packaging.

This module contains classes and functionality for creating and validating pipeline configuration packages.
"""
